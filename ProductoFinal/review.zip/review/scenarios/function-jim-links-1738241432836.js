(function(window, undefined) {

  var jimLinks = {
    "daec86d2-ae05-4d27-9563-7759b4bde71b" : {
      "Path_1" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ]
    },
    "98b5c234-a159-47ce-911a-5e52286c1d90" : {
      "Path_2" : [
        "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"
      ],
      "Button_1" : [
        "98b5c234-a159-47ce-911a-5e52286c1d90"
      ],
      "Rectangle_7" : [
        "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"
      ],
      "Path_1" : [
        "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"
      ]
    },
    "4054bd01-1ac4-48d3-a9e4-e87e0f41e9a1" : {
      "Button_2" : [
        "a259d7a2-4eb3-4adb-aece-996a95795970"
      ]
    },
    "a0db5d11-451f-4f4a-a9fa-b79decd9e112" : {
      "Path_1" : [
        "831b8015-4e16-4a38-bfc0-37182b94be7f"
      ]
    },
    "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0" : {
      "Path_1" : [
        "a259d7a2-4eb3-4adb-aece-996a95795970"
      ],
      "Button_1" : [
        "88a690f6-7da8-49cf-9b6b-4eb202e3c203"
      ],
      "Button_2" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Path_2" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Button_3" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Path_3" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Hotspot_1" : [
        "5a41d4ee-3412-473c-9d7b-0e7bc4404174"
      ]
    },
    "88a690f6-7da8-49cf-9b6b-4eb202e3c203" : {
      "Path_1" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Button_5" : [
        "daec86d2-ae05-4d27-9563-7759b4bde71b"
      ],
      "Button_1" : [
        "831b8015-4e16-4a38-bfc0-37182b94be7f"
      ]
    },
    "831b8015-4e16-4a38-bfc0-37182b94be7f" : {
      "Hotspot_1" : [
        "8cf06840-6391-4cec-a980-41ac44e4ced8"
      ],
      "Hotspot_2" : [
        "a0db5d11-451f-4f4a-a9fa-b79decd9e112"
      ],
      "Path_1" : [
        "88a690f6-7da8-49cf-9b6b-4eb202e3c203"
      ]
    },
    "a259d7a2-4eb3-4adb-aece-996a95795970" : {
      "Path_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_7" : [
        "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"
      ],
      "Rectangle_6" : [
        "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"
      ],
      "Rectangle_7" : [
        "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"
      ],
      "Rectangle_8" : [
        "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"
      ],
      "Button_5" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Path_1" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Button_1" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Path_3" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Hotspot_1" : [
        "5a41d4ee-3412-473c-9d7b-0e7bc4404174"
      ]
    },
    "80d0b2bc-1f32-4ebf-9e5a-a8107157e556" : {
      "Path_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_7" : [
        "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"
      ],
      "Rectangle_7" : [
        "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"
      ],
      "Rectangle_8" : [
        "a259d7a2-4eb3-4adb-aece-996a95795970"
      ],
      "Button_1" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Path_1" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Button_4" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Path_3" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Button_2" : [
        "98b5c234-a159-47ce-911a-5e52286c1d90"
      ]
    },
    "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357" : {
      "Path_1" : [
        "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"
      ],
      "Hotspot_1" : [
        "98b5c234-a159-47ce-911a-5e52286c1d90"
      ],
      "Button_1" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Path_14" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Button_2" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Path_15" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ]
    },
    "3a0d857b-2ccb-4f29-bccb-63ab1621360e" : {
      "Path_1" : [
        "a259d7a2-4eb3-4adb-aece-996a95795970"
      ],
      "Button_1" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Path_2" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Button_2" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Path_3" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Hotspot_2" : [
        "8cf06840-6391-4cec-a980-41ac44e4ced8"
      ]
    },
    "5f8941e1-2624-4a88-ab9c-73d3516a9ef3" : {
      "Button_2" : [
        "a259d7a2-4eb3-4adb-aece-996a95795970"
      ]
    },
    "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3" : {
      "Button_1" : [
        "98b5c234-a159-47ce-911a-5e52286c1d90"
      ],
      "Path_85" : [
        "98b5c234-a159-47ce-911a-5e52286c1d90"
      ]
    },
    "5a41d4ee-3412-473c-9d7b-0e7bc4404174" : {
      "Path_1" : [
        "a259d7a2-4eb3-4adb-aece-996a95795970"
      ]
    },
    "8cf06840-6391-4cec-a980-41ac44e4ced8" : {
      "Path_1" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Button_2" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Path_2" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Button_4" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Path_3" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Hotspot_1" : [
        "5a41d4ee-3412-473c-9d7b-0e7bc4404174"
      ]
    },
    "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc" : {
      "Path_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_7" : [
        "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"
      ],
      "Rectangle_6" : [
        "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"
      ],
      "Rectangle_8" : [
        "a259d7a2-4eb3-4adb-aece-996a95795970"
      ],
      "Button_3" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Path_1" : [
        "3a0d857b-2ccb-4f29-bccb-63ab1621360e"
      ],
      "Button_4" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Path_3" : [
        "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"
      ],
      "Button_1" : [
        "98b5c234-a159-47ce-911a-5e52286c1d90"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "5f8941e1-2624-4a88-ab9c-73d3516a9ef3"
      ],
      "Button_2" : [
        "4054bd01-1ac4-48d3-a9e4-e87e0f41e9a1"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);