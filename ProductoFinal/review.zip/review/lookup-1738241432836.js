(function(window, undefined) {
  var dictionary = {
    "daec86d2-ae05-4d27-9563-7759b4bde71b": "Mis plataformas",
    "98b5c234-a159-47ce-911a-5e52286c1d90": "Juego",
    "4054bd01-1ac4-48d3-a9e4-e87e0f41e9a1": "Registrarse",
    "a0db5d11-451f-4f4a-a9fa-b79decd9e112": "Grupo",
    "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0": "Perfil",
    "88a690f6-7da8-49cf-9b6b-4eb202e3c203": "Editar Perfil",
    "831b8015-4e16-4a38-bfc0-37182b94be7f": "Administrar Amigos",
    "a259d7a2-4eb3-4adb-aece-996a95795970": "Menu Principal - Reseñas",
    "80d0b2bc-1f32-4ebf-9e5a-a8107157e556": "Menu Principal - Juegos",
    "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357": "Buscar Juego",
    "3a0d857b-2ccb-4f29-bccb-63ab1621360e": "Buscar amigos",
    "5f8941e1-2624-4a88-ab9c-73d3516a9ef3": "Login",
    "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3": "Publicar",
    "5a41d4ee-3412-473c-9d7b-0e7bc4404174": "Reseña",
    "8cf06840-6391-4cec-a980-41ac44e4ced8": "Perfil otro usuario",
    "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc": "Menu Principal - Trending",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Inicio",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "Board 1"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);