	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Clear", "s-Path_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Card image", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_2", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Outlined button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Body small", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_2", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Body medium", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Title Large", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button_4", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Outlined button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Path_3", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Text", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_6", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Basic", "s-Group_37"]; 

	widgets.descriptionMap[["s-Paragraph_24", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_24", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Headline Small", "s-Paragraph_24"]; 

	widgets.descriptionMap[["s-Paragraph_25", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_25", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Basic", "s-Group_37"]; 

	widgets.descriptionMap[["s-Button_10", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_10", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Outlined button", "s-Button_10"]; 

	widgets.descriptionMap[["s-Button_11", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_11", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Outlined button", "s-Button_11"]; 

	widgets.descriptionMap[["s-Rectangle_12", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Radio list", "s-Group_59"]; 

	widgets.descriptionMap[["s-Button_18", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_18", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Outlined button", "s-Button_18"]; 

	widgets.descriptionMap[["s-Button_19", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_19", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Outlined button", "s-Button_19"]; 

	widgets.descriptionMap[["s-Path_103", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_103", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Radio list", "s-Group_59"]; 

	widgets.descriptionMap[["s-Paragraph_38", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_38", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Body large", "s-Paragraph_38"]; 

	widgets.descriptionMap[["s-Paragraph_39", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_39", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Body large", "s-Paragraph_39"]; 

	widgets.descriptionMap[["s-Paragraph_40", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_40", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Body large", "s-Paragraph_40"]; 

	widgets.descriptionMap[["s-Path_102", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_102", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Radio list", "s-Group_59"]; 

	widgets.descriptionMap[["s-Paragraph_41", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_41", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Headline Small", "s-Paragraph_41"]; 

	widgets.descriptionMap[["s-Input_7", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Radio list", "s-Group_59"]; 

	widgets.descriptionMap[["s-Input_8", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Radio list", "s-Group_59"]; 

	widgets.descriptionMap[["s-Input_9", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Radio list", "s-Group_59"]; 

	widgets.descriptionMap[["s-Radio_2", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Radio_2", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Radio list", "s-Group_59"]; 

	widgets.descriptionMap[["s-Radio_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Radio_1", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Radio list", "s-Group_59"]; 

	widgets.descriptionMap[["s-Text_3", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Body large", "s-Text_3"]; 

	widgets.descriptionMap[["s-Text_4", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "daec86d2-ae05-4d27-9563-7759b4bde71b"]] = ["Body large", "s-Text_4"]; 

	widgets.descriptionMap[["s-Rectangle_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Card image", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_3", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Title Large", "s-Text_3"]; 

	widgets.descriptionMap[["s-Path_2", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Arrow back", "s-Path_2"]; 

	widgets.descriptionMap[["s-Text_5", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Card image", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Two lines", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_4", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body small", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_3", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body large", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Rectangle_3", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Two lines", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_6", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body small", "s-Text_6"]; 

	widgets.descriptionMap[["s-Text_7", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body large", "s-Text_7"]; 

	widgets.descriptionMap[["s-Rectangle_4", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Three lines", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_2", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body small", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body large", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Two lines", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_5", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body small", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body large", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Text_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body small", "s-Text_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Two lines", "s-Group_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Body small", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Button_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Outlined button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_68", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Path_68", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["Favorite", "s-Path_68"]; 

	widgets.descriptionMap[["s-Rectangle_7", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["FAB", "s-Group_7"]; 

	widgets.descriptionMap[["s-Path_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "98b5c234-a159-47ce-911a-5e52286c1d90"]] = ["FAB", "s-Group_7"]; 

	widgets.descriptionMap[["s-Path_1", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_230", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Path_230", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Brightness low", "s-Path_230"]; 

	widgets.descriptionMap[["s-Text_3", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Body small", "s-Text_3"]; 

	widgets.descriptionMap[["s-Path_171", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Path_171", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Send", "s-Path_171"]; 

	widgets.descriptionMap[["s-Rectangle_2", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_4", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_5", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_6", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_6", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_7", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_7", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_8", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Hotspot_1", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "a0db5d11-451f-4f4a-a9fa-b79decd9e112"]] = ["Basic with icons", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_1", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Secondary tabs", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Secondary tabs", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_5", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Secondary tabs", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_6", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Three lines", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_6", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Body small", "s-Text_6"]; 

	widgets.descriptionMap[["s-Text_7", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Body large", "s-Text_7"]; 

	widgets.descriptionMap[["s-Button_2", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Tonal", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_2", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Group", "s-Path_2"]; 

	widgets.descriptionMap[["s-Button_3", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Tonal", "s-Button_3"]; 

	widgets.descriptionMap[["s-Path_3", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_3", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Title Medium", "s-Text_3"]; 

	widgets.descriptionMap[["s-Mask_1", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_1", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_5", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Stacked check", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_4", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Body small", "s-Text_4"]; 

	widgets.descriptionMap[["s-Text_5", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Title Medium", "s-Text_5"]; 

	widgets.descriptionMap[["s-Mask_2", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_2", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Stacked check", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_7", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Star", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "7f8f8dfe-ec05-4d9a-82b7-be25b31f26d0"]] = ["Star", "s-Path_8"]; 

	widgets.descriptionMap[["s-Input_2", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ["Input with label", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ["Input with label", "s-Group_2"]; 

	widgets.descriptionMap[["s-Input_text_1", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_1", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ["Input with label", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_4", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ["Input with label", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_101", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ""; 

			widgets.rootWidgetMap[["s-Path_101", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ["Edit", "s-Path_101"]; 

	widgets.descriptionMap[["s-Path_1", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ["Clear", "s-Path_1"]; 

	widgets.descriptionMap[["s-Button_5", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ["Tonal", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_1", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "88a690f6-7da8-49cf-9b6b-4eb202e3c203"]] = ["Tonal", "s-Button_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_3", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Body small", "s-Text_3"]; 

	widgets.descriptionMap[["s-Text_4", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Title Medium", "s-Text_4"]; 

	widgets.descriptionMap[["s-Ellipse_2", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Body small", "s-Text_5"]; 

	widgets.descriptionMap[["s-Text_6", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Title Medium", "s-Text_6"]; 

	widgets.descriptionMap[["s-Ellipse_3", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_7", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_5"]; 

	widgets.descriptionMap[["s-Text_7", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Body small", "s-Text_7"]; 

	widgets.descriptionMap[["s-Text_8", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Title Medium", "s-Text_8"]; 

	widgets.descriptionMap[["s-Ellipse_4", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_8", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_7"]; 

	widgets.descriptionMap[["s-Text_9", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_9", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Body small", "s-Text_9"]; 

	widgets.descriptionMap[["s-Text_10", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_10", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Title Medium", "s-Text_10"]; 

	widgets.descriptionMap[["s-Ellipse_5", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_5", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_7"]; 

	widgets.descriptionMap[["s-Rectangle_9", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_9"]; 

	widgets.descriptionMap[["s-Text_11", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_11", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Body small", "s-Text_11"]; 

	widgets.descriptionMap[["s-Text_12", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_12", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Title Medium", "s-Text_12"]; 

	widgets.descriptionMap[["s-Ellipse_6", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_10", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_11"]; 

	widgets.descriptionMap[["s-Text_14", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_14", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Title Medium", "s-Text_14"]; 

	widgets.descriptionMap[["s-Ellipse_7", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_7", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Stacked", "s-Group_11"]; 

	widgets.descriptionMap[["s-Path_1", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "831b8015-4e16-4a38-bfc0-37182b94be7f"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Arrow back", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_7", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Search", "s-Path_7"]; 

	widgets.descriptionMap[["s-Rectangle_5", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_7", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_8", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_9", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_14", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_2", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Body small", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Title Medium", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Mask_4", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_4", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_16", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Body small", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Title Medium", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Mask_5", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_5", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_18", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Body small", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Title Medium", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Mask_6", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_6", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_6"]; 

	widgets.descriptionMap[["s-Path_20", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_9", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Body small", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Title Medium", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Mask_7", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_7", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_7"]; 

	widgets.descriptionMap[["s-Path_8", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Body small", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Title Medium", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Mask_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_10", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Star", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Star", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Star", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Star", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_22", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Star", "s-Path_22"]; 

	widgets.descriptionMap[["s-Button_5", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Tonal", "s-Button_5"]; 

	widgets.descriptionMap[["s-Path_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Group", "s-Path_1"]; 

	widgets.descriptionMap[["s-Button_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Tonal", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_3", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "a259d7a2-4eb3-4adb-aece-996a95795970"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_2", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Arrow back", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_7", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Search", "s-Path_7"]; 

	widgets.descriptionMap[["s-Rectangle_5", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_7", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_8", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_9", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Card image", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Body small", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_2", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Body medium", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Title Large", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Card image", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Card image", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Card image", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_11", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Star", "s-Path_11"]; 

	widgets.descriptionMap[["s-Button_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Tonal", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Group", "s-Path_1"]; 

	widgets.descriptionMap[["s-Button_4", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Tonal", "s-Button_4"]; 

	widgets.descriptionMap[["s-Path_3", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "80d0b2bc-1f32-4ebf-9e5a-a8107157e556"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_1", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_3", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Title Medium", "s-Text_3"]; 

	widgets.descriptionMap[["s-Mask_1", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_1", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_3", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Title Medium", "s-Text_5"]; 

	widgets.descriptionMap[["s-Mask_2", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_2", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_6", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_7", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Title Medium", "s-Text_7"]; 

	widgets.descriptionMap[["s-Mask_3", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_3", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_7", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_9", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Text_9", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Title Medium", "s-Text_9"]; 

	widgets.descriptionMap[["s-Mask_4", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_4", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_8", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_5"]; 

	widgets.descriptionMap[["s-Text_11", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Text_11", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Title Medium", "s-Text_11"]; 

	widgets.descriptionMap[["s-Mask_5", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_5", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Stacked check", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_9", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Star", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Star", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Star", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Star", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Star", "s-Path_13"]; 

	widgets.descriptionMap[["s-Button_1", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Tonal", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_14", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Group", "s-Path_14"]; 

	widgets.descriptionMap[["s-Button_2", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Tonal", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_15", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "e59ea0b6-a4d6-4b2c-9c38-86dd54d9b357"]] = ["Account circle", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_9", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Filter list", "s-Path_9"]; 

	widgets.descriptionMap[["s-Rectangle_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_1"]; 

	widgets.descriptionMap[["s-Ellipse_2", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_6"]; 

	widgets.descriptionMap[["s-Paragraph_3", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Body small", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Title Medium", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Ellipse_4", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_6"]; 

	widgets.descriptionMap[["s-Text_9", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_9", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Body small", "s-Text_9"]; 

	widgets.descriptionMap[["s-Text_10", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_10", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Title Medium", "s-Text_10"]; 

	widgets.descriptionMap[["s-Ellipse_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_7", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_5", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Body small", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Title Medium", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Ellipse_6", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_10", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_12"]; 

	widgets.descriptionMap[["s-Paragraph_7", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Body small", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Title Medium", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Ellipse_8", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_8", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_12"]; 

	widgets.descriptionMap[["s-Rectangle_13", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_15"]; 

	widgets.descriptionMap[["s-Paragraph_9", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Body small", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Title Medium", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Ellipse_10", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_10", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Stacked", "s-Group_15"]; 

	widgets.descriptionMap[["s-Button_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Tonal", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_2", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Group", "s-Path_2"]; 

	widgets.descriptionMap[["s-Button_2", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Tonal", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_3", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Rectangle_2", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_3", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_8", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_5", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_11", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_11", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_6", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_12", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_12", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_8", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_13", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_13", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_9", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_14", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_14", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Menu minimum width", "s-Group_4"]; 

	widgets.descriptionMap[["s-Hotspot_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "3a0d857b-2ccb-4f29-bccb-63ab1621360e"]] = ["Basic with icons", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_2", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_3", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Title Medium", "s-Text_3"]; 

	widgets.descriptionMap[["s-Mask_1", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_1", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_2", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Input with label", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Input with label", "s-Group_2"]; 

	widgets.descriptionMap[["s-Input_9", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Text area", "s-Group_16"]; 

	widgets.descriptionMap[["s-Paragraph_9", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Text area", "s-Group_16"]; 

	widgets.descriptionMap[["s-Input_text_1", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_1", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Text area", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_4", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Text area", "s-Group_3"]; 

	widgets.descriptionMap[["s-Input_text_2", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_2", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Text area", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_5", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Text area", "s-Group_4"]; 

	widgets.descriptionMap[["s-Button_1", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_85", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "9f73a59f-e3df-4ff1-b908-ce6ba309f0a3"]] = ["Clear", "s-Path_85"]; 

	widgets.descriptionMap[["s-Path_1", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Stacked check", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Body small", "s-Text_5"]; 

	widgets.descriptionMap[["s-Text_2", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Body small", "s-Text_2"]; 

	widgets.descriptionMap[["s-Text_3", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Title Medium", "s-Text_3"]; 

	widgets.descriptionMap[["s-Path_3", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Star", "s-Path_3"]; 

	widgets.descriptionMap[["s-Rectangle_2", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Two lines", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_4", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Body small", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Rectangle_3", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["One line", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_5", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Body large", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Rectangle_1", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Three lines", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_2", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Body small", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Body large", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Two lines", "s-Group_6"]; 

	widgets.descriptionMap[["s-Paragraph_6", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Body small", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_3", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "5a41d4ee-3412-473c-9d7b-0e7bc4404174"]] = ["Body large", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Path_1", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Rectangle_37", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_37", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Secondary tabs", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_39", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_39", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Secondary tabs", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_40", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_40", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Secondary tabs", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_3", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Three lines", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_5", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Body small", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Body large", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Button_2", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Tonal", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_2", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Group", "s-Path_2"]; 

	widgets.descriptionMap[["s-Button_4", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Tonal", "s-Button_4"]; 

	widgets.descriptionMap[["s-Path_3", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_5", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_1", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Title Medium", "s-Text_1"]; 

	widgets.descriptionMap[["s-Mask_1", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_1", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Stacked check", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_6", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Stacked check", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_3", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Body small", "s-Text_3"]; 

	widgets.descriptionMap[["s-Text_4", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Title Medium", "s-Text_4"]; 

	widgets.descriptionMap[["s-Mask_2", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_2", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Stacked check", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_7", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Star", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "8cf06840-6391-4cec-a980-41ac44e4ced8"]] = ["Star", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_2", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Arrow back", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_7", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Search", "s-Path_7"]; 

	widgets.descriptionMap[["s-Rectangle_5", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_7", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_8", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Card image", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_2", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Body small", "s-Text_2"]; 

	widgets.descriptionMap[["s-Text_3", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Body medium", "s-Text_3"]; 

	widgets.descriptionMap[["s-Text_4", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Title Large", "s-Text_4"]; 

	widgets.descriptionMap[["s-Rectangle_2", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Card image", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Card image", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Card image", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_8", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Star", "s-Path_8"]; 

	widgets.descriptionMap[["s-Button_3", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Tonal", "s-Button_3"]; 

	widgets.descriptionMap[["s-Path_1", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Group", "s-Path_1"]; 

	widgets.descriptionMap[["s-Button_4", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Tonal", "s-Button_4"]; 

	widgets.descriptionMap[["s-Path_3", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc"]] = ["Account circle", "s-Path_3"]; 

	