var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Menu Principal - Trending"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/66f6911e-88bf-4e19-89ec-0a0ce5e4a1dc/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Path_2" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="29.78px" datasizeheight="22.75px" dataX="20.15" dataY="42.44"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.781021897810618" height="22.751039773296327" viewBox="20.145985401460415 42.44391404244118 29.781021897810618 22.751039773296327" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-66f69" d="M49.92700729927103 52.397493943258326 L27.274817376241852 52.397493943258326 L37.67956218580339 44.448849205492095 L35.036496350365724 42.44391404244118 L20.145985401460415 53.81943392908934 L35.036496350365724 65.1949538157375 L37.66094884298222 63.190018483178136 L27.274817376241852 55.241373914920366 L49.92700729927103 55.241373914920366 L49.92700729927103 52.397493943258326 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-66f69" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer ie-background commentable non-processed" customid="Line 3"   datasizewidth="362.00px" datasizeheight="3.00px" dataX="-0.50" dataY="79.86"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="360.999999999999" height="2.0" viewBox="-0.49999999999926104 79.86231366460125 360.999999999999 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-66f69" d="M7.389644451905042E-13 80.36231366460125 L359.9999999999997 80.36231366460125 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-66f69" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer click commentable non-processed" customid="Search"   datasizewidth="31.97px" datasizeheight="31.85px" dataX="308.76" dataY="37.55"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="31.970802919708547" height="31.8487154188659" viewBox="308.75912408759064 37.55254325107278 31.970802919708547 31.8487154188659" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-66f69" d="M331.60846895472366 57.583182175551556 L330.1643903198974 57.583182175551556 L329.6525649926945 57.091521018777485 C331.44395339275763 55.01561873672591 332.522442749409 52.320586414759035 332.522442749409 49.38882988826478 C332.522442749409 42.851557452327356 327.2031155432631 37.55254325107278 320.64078341849984 37.55254325107278 C314.0784512937365 37.55254325107278 308.75912408759064 42.851557452327356 308.75912408759064 49.38882988826478 C308.75912408759064 55.92610232420221 314.0784512937365 61.225116525456784 320.64078341849984 61.225116525456784 C323.58377906353553 61.225116525456784 326.2891413127611 60.15074593999151 328.37300175640297 58.366197965267645 L328.8665476251448 58.87606877642515 L328.8665476251448 60.31463288371144 L338.00628557199803 69.40125866993867 L340.7299270072992 66.68801805031464 L331.60846895472366 57.583182175551556 Z M320.64078341849984 57.583182175551556 C316.0891943393509 57.583182175551556 312.4150192663319 53.92303773711049 312.4150192663319 49.38882988826478 C312.4150192663319 44.854622039419084 316.0891943393509 41.19447760097801 320.64078341849984 41.19447760097801 C325.1923724976487 41.19447760097801 328.8665475706677 44.854622039419084 328.8665475706677 49.38882988826478 C328.8665475706677 53.92303773711049 325.1923724976487 57.583182175551556 320.64078341849984 57.583182175551556 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-66f69" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Primary tabs text" datasizewidth="360.00px" datasizeheight="52.00px" dataX="-0.00" dataY="728.00" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel"  datasizewidth="360.00px" datasizeheight="52.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.00px" datasizeheight="47.50px" datasizewidthpx="360.0" datasizeheightpx="47.5" dataX="0.00" dataY="2.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_5_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_6" class="rectangle manualfit firer click commentable non-processed" customid="Tab 3"   datasizewidth="120.00px" datasizeheight="39.00px" datasizewidthpx="120.00000000000023" datasizeheightpx="39.00000000000007" dataX="240.00" dataY="2.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_6_0">Juegos</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_7" class="rectangle manualfit firer click commentable non-processed" customid="Tab 2"   datasizewidth="120.00px" datasizeheight="40.00px" datasizewidthpx="119.99999999999977" datasizeheightpx="40.00000000000004" dataX="120.00" dataY="2.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_7_0">Trending</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_8" class="rectangle manualfit firer click ie-background commentable non-processed" customid="Tab 1"   datasizewidth="120.00px" datasizeheight="40.00px" datasizewidthpx="119.99999999999989" datasizeheightpx="40.0" dataX="0.43" dataY="2.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_8_0">Rese&ntilde;as</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_9" class="rectangle manualfit firer commentable non-processed" customid="Select tab"   datasizewidth="45.00px" datasizeheight="3.00px" datasizewidthpx="45.0" datasizeheightpx="3.0" dataX="157.50" dataY="770.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_9_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="MATA-Critics"   datasizewidth="217.90px" datasizeheight="32.00px" dataX="71.05" dataY="37.48" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">MATA-Critics</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Card with image" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="387.00px" datasizewidthpx="314.0" datasizeheightpx="387.0" dataX="23.00" dataY="166.49" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Explora el Salvaje Oeste "   datasizewidth="283.00px" datasizeheight="72.00px" dataX="38.50" dataY="422.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_2_0">Explora el Salvaje Oeste con Arthur Morgan en esta &eacute;pica historia de honor, traici&oacute;n y supervivencia. Disfruta de un mundo abierto lleno de detalles y aventuras.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Acci&oacute;n, Aventura, Mundo A"   datasizewidth="283.00px" datasizeheight="21.00px" dataX="38.50" dataY="395.99" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_3_0">Acci&oacute;n, Aventura, Mundo Abierto</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Red Dead Redemption 2"   datasizewidth="283.00px" datasizeheight="29.00px" dataX="38.50" dataY="362.99" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_4_0">Red Dead Redemption 2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Image space"   datasizewidth="312.00px" datasizeheight="177.81px" datasizewidthpx="312.0" datasizeheightpx="177.81203007518792" dataX="24.00" dataY="167.49" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Card with image" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="137.00px" datasizewidthpx="314.0000000000002" datasizeheightpx="137.00000263082597" dataX="23.00" dataY="582.82" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Image space"   datasizewidth="312.00px" datasizeheight="124.14px" datasizewidthpx="311.9999999999999" datasizeheightpx="124.14065537387887" dataX="24.00" dataY="584.68" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image lockV firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="314.00px" datasizeheight="180.18px" dataX="23.00" dataY="166.49" aspectRatio="0.57382846"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/ecfe4b23-29eb-446b-b716-664777b694cb.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="4.8/5"   datasizewidth="35.59px" datasizeheight="18.00px" dataX="64.00" dataY="508.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">4.8/5</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer commentable non-processed" customid="Star"   datasizewidth="20.00px" datasizeheight="19.00px" dataX="37.04" dataY="506.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="19.0" viewBox="37.03649635036609 506.0 20.0 19.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-66f69" d="M47.03649635036609 521.2700004577637 L53.216496655541874 525.0 L51.57649666984699 517.9699997901917 L57.03649635036609 513.2399997711182 L49.846496293145634 512.629999756813 L47.03649635036609 506.0 L44.226495930749394 512.6300001144409 L37.03649635036609 513.2399997711182 L42.496496388513066 517.9699997901917 L40.85649652202747 525.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-66f69" fill="#FFEB3B" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="314.00px" datasizeheight="137.18px" dataX="23.00" dataY="582.73"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d68c12bf-003f-481a-a410-f4004b4f5cc7.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="180.00px" datasizeheight="70.44px" dataX="-0.00" dataY="82.29" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Group"   datasizewidth="43.80px" datasizeheight="38.76px" dataX="68.10" dataY="98.13"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="43.795620437956075" height="38.76103072487501" viewBox="68.10218978102193 98.129498745012 43.795620437956075 38.76103072487501" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-66f69" d="M97.96284007962834 114.74136905567272 C101.26741864622701 114.74136905567272 103.91506305813544 111.03138459387833 103.91506305813544 106.43543390034236 C103.91506305813544 101.83948320680639 101.26741840891589 98.129498745012 97.96284007962834 98.129498745012 C94.65826151302969 98.129498745012 91.99071001990706 101.83948320680639 91.99071001990706 106.43543390034236 C91.99071001990706 111.03138459387833 94.65826151302969 114.74136905567272 97.96284007962834 114.74136905567272 Z M82.0371599203716 114.74136905567272 C85.34173848697026 114.74136905567272 87.98938289887869 111.03138459387833 87.98938289887869 106.43543390034236 C87.98938289887869 101.83948320680639 85.34173824965913 98.129498745012 82.0371599203716 98.129498745012 C78.73258159108406 98.129498745012 76.06502986065031 101.8394835368546 76.06502986065031 106.43543390034236 C76.06502986065031 111.03138426383012 78.73258135377293 114.74136905567272 82.0371599203716 114.74136905567272 Z M82.0371599203716 120.2786591592263 C77.39880572586719 120.2786591592263 68.10218978102193 123.51797375098778 68.10218978102193 129.96891684044505 L68.10218978102193 136.890529469887 L95.97213005972125 136.890529469887 L95.97213005972125 129.96891684044505 C95.97213005972125 123.517974081036 86.675514114876 120.2786591592263 82.0371599203716 120.2786591592263 Z M97.96284007962834 120.2786591592263 C97.38553419046707 120.2786591592263 96.7285998577935 120.33403205902415 96.0318513033638 120.41709141387794 C98.3410748600089 122.74275318475983 99.95355009953545 125.87132224508977 99.95355009953545 129.96891697452713 L99.95355009953545 136.890529469887 L111.89781021897801 136.890529469887 L111.89781021897801 129.96891684044505 C111.89781021897801 123.517974081036 102.60119427413275 120.2786591592263 97.96284007962834 120.2786591592263 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-66f69" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="180.00px" datasizeheight="70.44px" dataX="180.00" dataY="82.29" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer click commentable non-processed" customid="Account_circle"   datasizewidth="46.42px" datasizeheight="44.66px" dataX="246.79" dataY="95.18"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="46.423357664232924" height="44.659448443877864" viewBox="246.78832116788448 95.1802898855104 46.423357664232924 44.659448443877864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-66f69" d="M270.00000000000097 95.1802898855104 C257.18715332894544 95.1802898855104 246.78832116788448 105.18400637952962 246.78832116788448 117.51001410744934 C246.78832116788448 129.83602183536905 257.18715332894544 139.83973832938827 270.00000000000097 139.83973832938827 C282.81284667105643 139.83973832938827 293.2116788321174 129.83602183536905 293.2116788321174 117.51001410744934 C293.2116788321174 105.18400637952962 282.81284777787556 95.1802898855104 270.00000000000097 95.1802898855104 Z M270.00000000000097 101.87920715209208 C273.85313860865494 101.87920715209208 276.96350364963587 104.8713902723654 276.96350364963587 108.57812441867377 C276.96350364963587 112.28485856498213 273.85313860865494 115.27704168525544 270.00000000000097 115.27704168525544 C266.14686139134693 115.27704168525544 263.036496350366 112.28485856498213 263.036496350366 108.57812441867377 C263.036496350366 104.8713902723654 266.14686139134693 101.87920715209208 270.00000000000097 101.87920715209208 Z M270.00000000000097 133.5874151213397 C264.1970802919718 133.5874151213397 259.06729918152854 130.72921048481737 256.07299270073105 126.3972438579895 C256.14262773567094 121.95362871652836 265.3576642335777 119.51968896799457 270.00000000000097 119.51968896799457 C274.6191241097285 119.51968896799457 283.857371775774 121.95362898271941 283.9270072992708 126.3972438579895 C280.93270081847334 130.72921048481737 275.80291970803006 133.5874151213397 270.00000000000097 133.5874151213397 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-66f69" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click ie-background commentable non-processed" customid="Button"   datasizewidth="297.96px" datasizeheight="378.00px" dataX="31.02" dataY="170.99" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Button</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;