var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-4054bd01-1ac4-48d3-a9e4-e87e0f41e9a1" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Registrarse"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/4054bd01-1ac4-48d3-a9e4-e87e0f41e9a1/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/4054bd01-1ac4-48d3-a9e4-e87e0f41e9a1/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="REGISTRARSE"   datasizewidth="311.88px" datasizeheight="32.00px" dataX="24.00" dataY="177.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">REGISTRARSE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_text_1" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="29.56" dataY="269.50" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Usuario"/></div></div>  </div></div></div>\
      <div id="s-Input_text_2" class="text firer commentable non-processed" customid="Input text 2"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="29.56" dataY="374.50" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Contrase&ntilde;a"/></div></div>  </div></div></div>\
      <div id="s-Input_text_3" class="text firer commentable non-processed" customid="Input text 2"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="29.56" dataY="476.50" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Confirmar contrase&ntilde;a"/></div></div>  </div></div></div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Registrarse"   datasizewidth="267.00px" datasizeheight="45.00px" dataX="46.50" dataY="580.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Registrarse</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;