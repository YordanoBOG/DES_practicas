var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-831b8015-4e16-4a38-bfc0-37182b94be7f" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Administrar Amigos"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/831b8015-4e16-4a38-bfc0-37182b94be7f/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/831b8015-4e16-4a38-bfc0-37182b94be7f/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="MATA-Critics"   datasizewidth="217.90px" datasizeheight="32.00px" dataX="71.05" dataY="37.48" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">MATA-Critics</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Line 3"   datasizewidth="362.00px" datasizeheight="3.00px" dataX="-0.50" dataY="116.86"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="360.999999999999" height="2.0" viewBox="-0.49999999999926104 116.86231366460125 360.999999999999 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-831b8" d="M7.389644451905042E-13 117.36231366460125 L359.9999999999997 117.36231366460125 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-831b8" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="Administrar Amigos"   datasizewidth="208.05px" datasizeheight="27.00px" dataX="75.97" dataY="80.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Administrar Amigos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Primary tabs text" datasizewidth="360.00px" datasizeheight="51.00px" dataX="-0.00" dataY="118.36" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel"  datasizewidth="360.00px" datasizeheight="51.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.00px" datasizeheight="47.50px" datasizewidthpx="360.0" datasizeheightpx="47.5" dataX="0.00" dataY="1.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_1_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_3" class="rectangle manualfit firer click commentable non-processed" customid="Tab 2"   datasizewidth="120.00px" datasizeheight="35.00px" datasizewidthpx="119.99999999999986" datasizeheightpx="35.0" dataX="190.00" dataY="8.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_3_0">Grupos</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_4" class="rectangle manualfit firer click ie-background commentable non-processed" customid="Tab 1"   datasizewidth="120.00px" datasizeheight="35.00px" datasizewidthpx="120.0" datasizeheightpx="35.0" dataX="49.00" dataY="8.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_4_0">Amigos</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Select tab"   datasizewidth="45.00px" datasizeheight="3.00px" datasizewidthpx="45.0" datasizeheightpx="3.0" dataX="86.50" dataY="48.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_5_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="24.00" dataY="192.95" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_1" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="42.00" dataY="211.94" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0">A</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="24.00" dataY="305.11" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_6_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="@knekro"   datasizewidth="55.48px" datasizeheight="18.00px" dataX="98.00" dataY="350.09" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_3_0">@knekro</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Sergio Garc&iacute;a"   datasizewidth="228.52px" datasizeheight="21.00px" dataX="98.00" dataY="326.09" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_4_0">Sergio Garc&iacute;a</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_2" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="42.00" dataY="324.09" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_2)">\
                              <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_2" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_2_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="@illojuan"   datasizewidth="58.06px" datasizeheight="18.00px" dataX="96.96" dataY="238.11" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_5_0">@illojuan</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Juan Alberto"   datasizewidth="196.52px" datasizeheight="21.00px" dataX="96.96" dataY="214.11" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_6_0">Juan Alberto</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_3" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="40.96" dataY="212.11" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_3)">\
                              <ellipse id="s-Ellipse_3" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_3" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_3_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="24.00" dataY="418.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_7_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Text_7" class="richtext autofit firer ie-background commentable non-processed" customid="@ibai"   datasizewidth="35.71px" datasizeheight="18.00px" dataX="98.00" dataY="463.48" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_7_0">@ibai</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_8" class="richtext manualfit firer ie-background commentable non-processed" customid="Ibai Llanos"   datasizewidth="229.52px" datasizeheight="21.00px" dataX="98.00" dataY="439.48" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_8_0">Ibai Llanos</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_4" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="42.00" dataY="437.48" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_4)">\
                              <ellipse id="s-Ellipse_4" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_4" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_4_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_8" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="24.00" dataY="533.20" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_8_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Text_9" class="richtext autofit firer ie-background commentable non-processed" customid="@TheGrefg"   datasizewidth="71.28px" datasizeheight="18.00px" dataX="98.00" dataY="578.19" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_9_0">@TheGrefg</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_10" class="richtext manualfit firer ie-background commentable non-processed" customid="David C&aacute;novas"   datasizewidth="223.52px" datasizeheight="21.00px" dataX="98.00" dataY="554.19" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_10_0">David C&aacute;novas</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_5" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_5 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="42.00" dataY="552.19" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_5" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_5)">\
                              <ellipse id="s-Ellipse_5" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_5" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_5" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_5_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_9" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="24.00" dataY="649.90" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_9_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Text_11" class="richtext autofit firer ie-background commentable non-processed" customid="Ra&uacute;l &Aacute;lvarez"   datasizewidth="76.81px" datasizeheight="18.00px" dataX="98.00" dataY="694.89" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_11_0">Ra&uacute;l &Aacute;lvarez</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_12" class="richtext manualfit firer ie-background commentable non-processed" customid="AuronPlay"   datasizewidth="221.52px" datasizeheight="21.00px" dataX="98.00" dataY="670.89" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_12_0">AuronPlay</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_6" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="42.00" dataY="668.89" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_6)">\
                              <ellipse id="s-Ellipse_6" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_6" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_6_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="41.00" dataY="211.95"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4ed65e10-a352-49d1-bcb0-dec1b109b502.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="290.36px" datasizeheight="80.00px" dataX="36.00" dataY="194.00"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="41.00" dataY="323.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/66f3d836-4fec-497e-884b-394002bb932d.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="41.00" dataY="437.50"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e50477f2-0ac7-4c92-bd0e-de12d257f56b.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="41.00" dataY="552.20"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/85e1ccbc-8f5f-4dda-80a1-0bb0c66e6890.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="image firer ie-background commentable non-processed" customid="Image 5"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="41.00" dataY="668.90"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d8e24203-defa-4e19-b3d8-b3fb888dc02b.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_11" class="group firer ie-background commentable hidden non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_10" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="23.00" dataY="192.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_10_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_12" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Text_14" class="richtext manualfit firer ie-background commentable non-processed" customid="Grupo fornite"   datasizewidth="229.52px" datasizeheight="21.00px" dataX="107.48" dataY="223.95" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_14_0">Grupo fornite</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_7" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_7 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="41.00" dataY="211.48" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_7" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_7)">\
                              <ellipse id="s-Ellipse_7" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_7" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_7" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_7_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Image_6" class="image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="40.00" dataY="211.95"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e50477f2-0ac7-4c92-bd0e-de12d257f56b.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_7" class="image firer ie-background commentable hidden non-processed" customid="Image 7"   datasizewidth="52.95px" datasizeheight="44.85px" dataX="36.03" dataY="212.03"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/7111646c-7023-48d9-8c7d-002e2f46ba2d.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 2"   datasizewidth="315.00px" datasizeheight="80.00px" dataX="23.00" dataY="194.45"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="29.78px" datasizeheight="23.00px" dataX="13.11" dataY="41.98"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.78102189781059" height="23.000310830500325" viewBox="13.109489051094812 41.97674554525594 29.78102189781059 23.000310830500325" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-831b8" d="M42.8905109489054 52.03938153359983 L20.238321025876246 52.03938153359983 L30.643065835437774 44.00364771784572 L28.0000000000001 41.97674554525594 L13.109489051094812 53.4769009605061 L28.0000000000001 64.97705637575626 L30.624452492616612 62.95015403180081 L20.238321025876246 54.91442038741237 L42.8905109489054 54.91442038741237 L42.8905109489054 52.03938153359983 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-831b8" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;