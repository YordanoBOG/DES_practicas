var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-5f8941e1-2624-4a88-ab9c-73d3516a9ef3" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Login"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/5f8941e1-2624-4a88-ab9c-73d3516a9ef3/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/5f8941e1-2624-4a88-ab9c-73d3516a9ef3/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Iniciar sesi&oacute;n"   datasizewidth="311.88px" datasizeheight="32.00px" dataX="24.06" dataY="220.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Iniciar sesi&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_text_1" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="30.00" dataY="301.62" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Usuario"/></div></div>  </div></div></div>\
      <div id="s-Input_text_2" class="text firer commentable non-processed" customid="Input text 2"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="30.00" dataY="406.62" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Contrase&ntilde;a"/></div></div>  </div></div></div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Inciar sesi&oacute;n"   datasizewidth="264.00px" datasizeheight="45.00px" dataX="48.50" dataY="503.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Inciar sesi&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;