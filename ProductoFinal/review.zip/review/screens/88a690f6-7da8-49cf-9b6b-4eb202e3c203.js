var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-88a690f6-7da8-49cf-9b6b-4eb202e3c203" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Editar Perfil"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/88a690f6-7da8-49cf-9b6b-4eb202e3c203/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/88a690f6-7da8-49cf-9b6b-4eb202e3c203/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="87.59px" datasizeheight="85.19px" dataX="225.99" dataY="57.93"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4ed65e10-a352-49d1-bcb0-dec1b109b502.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Juan Alberto"   datasizewidth="145.98px" datasizeheight="29.00px" dataX="50.80" dataY="86.03" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Juan Alberto</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="362.00px" datasizeheight="3.00px" dataX="-0.50" dataY="157.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="361.00000000000006" height="2.0" viewBox="-0.4999999999998863 156.99999999999997 361.00000000000006 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-88a69" d="M1.1368683772161603E-13 157.49999999999997 L360.00000000000017 157.49999999999997 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-88a69" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Input with label" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Input_2" class="text firer focusin focusout commentable non-processed" customid="Input"  datasizewidth="309.00px" datasizeheight="56.00px" dataX="25.00" dataY="192.64" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Input"/></div></div>  </div></div></div>\
        <div id="s-Paragraph_1" class="richtext autofit firer commentable non-processed" customid="Nombre Usuario"   datasizewidth="104.86px" datasizeheight="25.00px" dataX="37.50" dataY="180.14" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Nombre Usuario</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Input with label" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Input_text_1" class="text firer focusin focusout commentable non-processed" customid="Input"  datasizewidth="309.00px" datasizeheight="56.00px" dataX="25.00" dataY="296.64" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Input"/></div></div>  </div></div></div>\
        <div id="s-Text_4" class="richtext autofit firer commentable non-processed" customid="Biograf&iacute;a"   datasizewidth="63.47px" datasizeheight="25.00px" dataX="37.50" dataY="284.14" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_4_0">Biograf&iacute;a</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_101" class="path firer commentable non-processed" customid="Edit"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="316.00" dataY="128.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.00249907374382" height="18.002499908208847" viewBox="315.99750092625646 128.0 18.00249907374382 18.002499908208847" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_101-88a69" d="M315.99750092625646 142.25249990820885 L315.99750092625646 146.00249990820885 L319.74750092625646 146.00249990820885 L330.80750039219885 134.94249948859215 L327.05750039219885 131.19249948859215 L315.99750092625646 142.25249990820885 Z M333.7075000107291 132.04249987006187 C334.097499996424 131.652499884367 334.097499996424 131.02249988913536 333.7075000107291 130.63249990344048 L331.3675000965598 128.29249998927116 C330.9775001108649 127.90250000357628 330.3475001156333 127.90250000357628 329.9575001299384 128.29249998927116 L328.12750008702307 130.1225000321865 L331.87750008702307 133.8725000321865 L333.7075001299384 132.04249998927116 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_101-88a69" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Clear"   datasizewidth="24.00px" datasizeheight="23.00px" dataX="22.25" dataY="41.98"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="24.0" height="22.999999999999996" viewBox="22.250000000000092 41.97690096050579 24.0 22.999999999999996" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-88a69" d="M46.25000000000009 44.29332928125425 L43.832857404436474 41.97690096050579 L34.25000000000009 51.16047263975732 L24.66714259556371 41.97690096050579 L22.250000000000092 44.29332928125425 L31.832857404436474 53.47690096050579 L22.250000000000092 62.660472639757316 L24.66714259556371 64.97690096050579 L34.25000000000009 55.79332928125425 L43.832857404436474 64.97690096050579 L46.25000000000009 62.660472639757316 L36.66714259556371 53.47690096050579 L46.25000000000009 44.29332928125425 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-88a69" fill="#FF0000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="Gestionar Plataformas"   datasizewidth="203.00px" datasizeheight="56.00px" dataX="78.50" dataY="408.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">Gestionar Plataformas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Administrar Amigos"   datasizewidth="203.00px" datasizeheight="56.00px" dataX="78.50" dataY="496.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Administrar Amigos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;