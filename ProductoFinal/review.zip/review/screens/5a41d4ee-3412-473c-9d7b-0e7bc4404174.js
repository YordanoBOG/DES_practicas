var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-5a41d4ee-3412-473c-9d7b-0e7bc4404174" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Rese&ntilde;a"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/5a41d4ee-3412-473c-9d7b-0e7bc4404174/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/5a41d4ee-3412-473c-9d7b-0e7bc4404174/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="29.78px" datasizeheight="22.75px" dataX="20.15" dataY="42.44"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.781021897810618" height="22.751039773296327" viewBox="20.145985401460415 42.44391404244118 29.781021897810618 22.751039773296327" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-5a41d" d="M49.92700729927103 52.397493943258326 L27.274817376241852 52.397493943258326 L37.67956218580339 44.448849205492095 L35.036496350365724 42.44391404244118 L20.145985401460415 53.81943392908934 L35.036496350365724 65.1949538157375 L37.66094884298222 63.190018483178136 L27.274817376241852 55.241373914920366 L49.92700729927103 55.241373914920366 L49.92700729927103 52.397493943258326 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-5a41d" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="MATA-Critics"   datasizewidth="217.90px" datasizeheight="32.00px" dataX="71.05" dataY="37.48" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">MATA-Critics</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Stacked card with checkbox" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_2" class="path firer commentable non-processed" customid="BG"   datasizewidth="338.00px" datasizeheight="141.00px" dataX="12.00" dataY="92.60"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="338.0000000000002" height="141.00000651289736" viewBox="11.99999999999909 92.5999623157387 338.0000000000002 141.00000651289736" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_2-5a41d" d="M28.146496815285722 92.59996231573871 L333.85350318471274 92.59996231573871 C342.71120928566535 92.59996231573871 349.9999999999993 104.10291857838786 349.9999999999993 118.08189120361169 L349.9999999999993 208.11803994076308 C349.9999999999993 222.09701256598703 342.71120928566535 233.59996882863607 333.85350318471274 233.59996882863607 L28.146496815285722 233.59996882863607 C19.288790714332983 233.59996882863607 11.99999999999909 222.09701256598703 11.99999999999909 208.11803994076308 L11.99999999999909 118.08189120361169 C11.99999999999909 104.10291857838786 19.288790714332983 92.59996231573871 28.146496815285722 92.59996231573871 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-5a41d" fill="#F3EDF7" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="Text"   datasizewidth="1.00px" datasizeheight="1.00px" dataX="126.79" dataY="170.93" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_5_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="109.85px" datasizeheight="111.00px" dataX="20.15" dataY="106.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e497bbbf-dbd3-42d2-9b08-4447d7d44fa3.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Stacked card with checkbox" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="@VaqueroSalvaje"   datasizewidth="109.41px" datasizeheight="18.00px" dataX="157.31" dataY="168.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_2_0">@VaqueroSalvaje</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Red Dead Redemption 2"   datasizewidth="187.34px" datasizeheight="58.00px" dataX="157.00" dataY="106.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_3_0">Red Dead Redemption 2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_3" class="path firer commentable non-processed" customid="Star"   datasizewidth="20.00px" datasizeheight="19.00px" dataX="206.79" dataY="198.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="19.0" viewBox="206.79296875000023 198.5000000000003 20.0 19.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-5a41d" d="M216.79296875000023 213.77000045776398 L222.972969055176 217.5000000000003 L221.33296906948112 210.46999979019196 L226.79296875000023 205.73999977111848 L219.60296869277977 205.12999975681336 L216.79296875000023 198.5000000000003 L213.98296833038353 205.13000011444123 L206.79296875000023 205.73999977111848 L212.2529687881472 210.46999979019196 L210.6129689216616 217.5000000000003 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-5a41d" fill="#FFEB3B" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext autofit firer ie-background commentable non-processed" customid="4.8/5"   datasizewidth="35.59px" datasizeheight="18.00px" dataX="157.00" dataY="199.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">4.8/5</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Two lines item list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.00px" datasizeheight="154.00px" datasizewidthpx="360.0" datasizeheightpx="154.0000000000001" dataX="0.00" dataY="310.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Este juego redefine lo qu"   datasizewidth="330.18px" datasizeheight="144.00px" dataX="16.00" dataY="310.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">Este juego redefine lo que significa un mundo abierto. Cada detalle es perfecto, desde los paisajes hasta las misiones. La historia de Arthur Morgan es emotiva y llena de giros sorprendentes. El &uacute;nico punto d&eacute;bil es que puede sentirse un poco lento para jugadores impacientes, pero si te gusta disfrutar del viaje, este juego es un 10/10. &iexcl;Recomendado al 100%!</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="One line item list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.00px" datasizeheight="56.00px" datasizewidthpx="360.0" datasizeheightpx="56.0" dataX="0.00" dataY="254.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Un viaje inolvidable por "   datasizewidth="332.18px" datasizeheight="21.00px" dataX="16.00" dataY="272.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">Un viaje inolvidable por el Salvaje Oeste</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Three lines item list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.00px" datasizeheight="110.00px" datasizewidthpx="360.0" datasizeheightpx="110.00000000000006" dataX="0.00" dataY="464.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Supporting text"   datasizewidth="207.00px" datasizeheight="54.00px" dataX="16.00" dataY="503.73" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">✅ Gr&aacute;ficos impresionantes.<br />✅ Historia envolvente.<br />✅ Mundo abierto interactivo.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Pros:"   datasizewidth="55.77px" datasizeheight="21.00px" dataX="17.00" dataY="480.73" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Pros:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Two lines item list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.00px" datasizeheight="97.00px" datasizewidthpx="360.0" datasizeheightpx="97.0" dataX="0.00" dataY="574.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="❌ Ritmo lento en algunas "   datasizewidth="254.08px" datasizeheight="57.00px" dataX="16.00" dataY="614.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">❌ Ritmo lento en algunas partes.<br />❌ Algunos bugs menores.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Contras:"   datasizewidth="75.18px" datasizeheight="21.00px" dataX="16.00" dataY="591.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">Contras:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Line_1" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="340.00px" datasizeheight="3.00px" dataX="11.50" dataY="253.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="339.0000000000001" height="2.0" viewBox="11.5 252.99999999999997 339.0000000000001 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Line_1-5a41d" d="M12.0 253.49999999999997 L350.0000000000001 253.99999999999991 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_1-5a41d" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;