var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-a0db5d11-451f-4f4a-a9fa-b79decd9e112" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Grupo"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/a0db5d11-451f-4f4a-a9fa-b79decd9e112/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/a0db5d11-451f-4f4a-a9fa-b79decd9e112/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="29.78px" datasizeheight="23.00px" dataX="18.91" dataY="38.93"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.78102189781059" height="23.000310830500325" viewBox="18.91240875912448 38.93425287356314 29.78102189781059 23.000310830500325" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-a0db5" d="M48.69343065693507 48.99688886190703 L26.041240733905916 48.99688886190703 L36.445985543467444 40.961155046152925 L33.80291970802977 38.93425287356314 L18.91240875912448 50.4344082888133 L33.80291970802977 61.934563704063464 L36.42737220064628 59.90766136010801 L26.041240733905916 51.87192771571957 L48.69343065693507 51.87192771571957 L48.69343065693507 48.99688886190703 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-a0db5" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="MATA-Critics"   datasizewidth="217.90px" datasizeheight="32.00px" dataX="71.05" dataY="37.48" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">MATA-Critics</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="Grupo fornite"   datasizewidth="140.07px" datasizeheight="27.00px" dataX="109.96" dataY="81.36" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Grupo fornite</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Line 3"   datasizewidth="362.00px" datasizeheight="3.00px" dataX="-0.50" dataY="116.86"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="360.999999999999" height="2.0" viewBox="-0.49999999999926104 116.86231366460125 360.999999999999 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-a0db5" d="M7.389644451905042E-13 117.36231366460125 L359.9999999999997 117.36231366460125 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-a0db5" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable hidden non-processed" customid="Image 7"   datasizewidth="52.95px" datasizeheight="44.85px" dataX="21.11" dataY="69.52"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/7111646c-7023-48d9-8c7d-002e2f46ba2d.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Path_230" class="path firer commentable non-processed" customid="Brightness Low"   datasizewidth="30.00px" datasizeheight="30.00px" dataX="302.00" dataY="79.86"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.999999999999996" height="29.999999999999996" viewBox="302.0 79.86231366460154 29.999999999999996 29.999999999999996" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_230-a0db5" d="M327.6100801807128 99.25223510443942 L332.0 94.86231402033219 L327.6100801807128 90.47239293622496 L327.6100801807128 84.25223419534998 L321.3899208074278 84.25223419534998 L317.00000035573066 79.86231366460154 L312.6100792716234 84.25223419534998 L306.38992053074844 84.25223419534998 L306.38992053074844 90.472393568635 L302.0 94.86231402033219 L306.38992053074844 99.25223510443942 L306.38992053074844 105.4723938453144 L312.61007990403346 105.4723938453144 L317.00000035573066 109.86231366460154 L321.38992143983785 105.4723938453144 L327.6100801807128 105.4723938453144 L327.6100801807128 99.25223447202937 Z M317.00000035573066 102.81987388906884 C312.61007990403346 102.81987388906884 309.042440486994 99.25223447202937 309.042440486994 94.86231402033219 C309.042440486994 90.472393568635 312.61007990403346 86.90475415159554 317.00000035573066 86.90475415159554 C321.3899208074278 86.90475415159554 324.95756022446733 90.472393568635 324.95756022446733 94.86231402033219 C324.95756022446733 99.25223447202937 321.3899208074278 102.81987388906884 317.00000035573066 102.81987388906884 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_230-a0db5" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="200.00px" datasizeheight="64.00px" datasizewidthpx="200.0" datasizeheightpx="63.99999999999994" dataX="9.96" dataY="157.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Habeis visto la nueva actualizaci&oacute;n?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="@ibai"   datasizewidth="35.71px" datasizeheight="18.00px" dataX="51.19" dataY="135.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">@ibai</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="-0.00" dataY="121.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e50477f2-0ac7-4c92-bd0e-de12d257f56b.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="text firer focusin focusout commentable non-processed" customid="Input"  datasizewidth="309.00px" datasizeheight="56.00px" dataX="51.00" dataY="724.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Input"/></div></div>  </div></div></div>\
      <div id="s-Path_171" class="path firer commentable non-processed" customid="Send"   datasizewidth="30.00px" datasizeheight="30.00px" dataX="14.00" dataY="737.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="30.000000000000007" height="30.0" viewBox="13.999999999999837 737.0 30.000000000000007 30.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_171-a0db5" d="M14.014285700661631 767.0 L43.999999999999844 752.0 L14.014285700661631 737.0 L13.999999999999837 748.6666666666666 L35.42857142857126 752.0 L13.999999999999837 755.3333333333334 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_171-a0db5" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Basic menu with icons" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Group_2" class="group firer ie-background commentable hidden non-processed" customid="Menu with icons" datasizewidth="112.00px" datasizeheight="158.00px" >\
          <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="251.50px" datasizeheight="315.36px" datasizewidthpx="251.49999999999943" datasizeheightpx="315.3581615755304" dataX="80.00" dataY="121.00" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_2_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Item 4" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_3" class="rectangle manualfit firer click commentable non-processed" customid="Item 4"   datasizewidth="251.50px" datasizeheight="77.35px" datasizewidthpx="251.49999999999943" datasizeheightpx="77.34604710356143" dataX="80.00" dataY="359.35" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_3_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_4" class="richtext manualfit firer click ie-background commentable non-processed" customid="Editar"   datasizewidth="162.63px" datasizeheight="42.00px" dataX="124.43" dataY="377.50" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_4_0">Editar</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Item 3" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_4" class="rectangle manualfit firer click commentable non-processed" customid="Item 3"   datasizewidth="251.50px" datasizeheight="75.67px" datasizewidthpx="251.49999999999943" datasizeheightpx="75.66755634634568" dataX="80.00" dataY="283.58" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_4_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_5" class="richtext manualfit firer click ie-background commentable non-processed" customid="Salir"   datasizewidth="159.63px" datasizeheight="42.00px" dataX="125.93" dataY="305.61" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_5_0">Salir</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Item 2" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_5" class="rectangle manualfit firer click commentable non-processed" customid="Item 2"   datasizewidth="251.30px" datasizeheight="75.57px" datasizewidthpx="251.2999999999994" datasizeheightpx="75.56755634634558" dataX="80.00" dataY="209.40" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_5_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_6" class="richtext manualfit firer click ie-background commentable non-processed" customid="Buscar"   datasizewidth="159.63px" datasizeheight="33.15px" dataX="125.93" dataY="233.77" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_6_0">Buscar</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Item 1" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_6" class="rectangle manualfit firer click commentable non-processed" customid="Item 1"   datasizewidth="251.50px" datasizeheight="75.77px" datasizewidthpx="251.49999999999943" datasizeheightpx="75.7675563463457" dataX="80.00" dataY="133.63" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_6_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_7" class="richtext manualfit firer click ie-background commentable non-processed" customid="Silenciar"   datasizewidth="159.93px" datasizeheight="42.00px" dataX="125.79" dataY="151.95" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_7_0">Silenciar</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Item 1" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_7" class="rectangle manualfit firer click commentable non-processed" customid="Item 1"   datasizewidth="251.50px" datasizeheight="75.77px" datasizewidthpx="251.49999999999943" datasizeheightpx="75.7675563463457" dataX="80.00" dataY="436.97" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_7_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_8" class="richtext manualfit firer click ie-background commentable non-processed" customid="Info. del Grupo"   datasizewidth="159.93px" datasizeheight="42.00px" dataX="125.79" dataY="455.29" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_8_0">Info. del Grupo</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
        <div id="s-Hotspot_1" class="imagemap firer toggle ie-background commentable non-processed" customid="Hotspot"   datasizewidth="31.00px" datasizeheight="35.00px" dataX="300.50" dataY="80.00"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;