var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-daec86d2-ae05-4d27-9563-7759b4bde71b" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Mis plataformas"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/daec86d2-ae05-4d27-9563-7759b4bde71b/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/daec86d2-ae05-4d27-9563-7759b4bde71b/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Clear"   datasizewidth="24.00px" datasizeheight="23.00px" dataX="22.25" dataY="41.98"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="24.0" height="22.999999999999996" viewBox="22.250000000000092 41.97690096050579 24.0 22.999999999999996" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-daec8" d="M46.25000000000009 44.29332928125425 L43.832857404436474 41.97690096050579 L34.25000000000009 51.16047263975732 L24.66714259556371 41.97690096050579 L22.250000000000092 44.29332928125425 L31.832857404436474 53.47690096050579 L22.250000000000092 62.660472639757316 L24.66714259556371 64.97690096050579 L34.25000000000009 55.79332928125425 L43.832857404436474 64.97690096050579 L46.25000000000009 62.660472639757316 L36.66714259556371 53.47690096050579 L46.25000000000009 44.29332928125425 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-daec8" fill="#FF0000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="MATA-Critics"   datasizewidth="217.90px" datasizeheight="32.00px" dataX="71.05" dataY="37.48" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">MATA-Critics</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Line 3"   datasizewidth="362.00px" datasizeheight="3.00px" dataX="-0.50" dataY="116.86"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="360.999999999999" height="2.0" viewBox="-0.49999999999926104 116.86231366460125 360.999999999999 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-daec8" d="M7.389644451905042E-13 117.36231366460125 L359.9999999999997 117.36231366460125 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-daec8" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="Mis Plataformas"   datasizewidth="172.04px" datasizeheight="27.00px" dataX="93.98" dataY="85.36" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Mis Plataformas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Card with image" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="159.00px" datasizewidthpx="313.9999999999999" datasizeheightpx="158.9999999999999" dataX="23.00" dataY="168.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Outlined button"   datasizewidth="123.00px" datasizeheight="40.00px" dataX="50.05" dataY="272.05" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_2_0">Eliminar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="120.00px" datasizeheight="40.00px" dataX="195.00" dataY="272.05" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0">Reclamar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Plataforma de distribuci&oacute;"   datasizewidth="171.54px" datasizeheight="36.00px" dataX="39.46" dataY="211.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">Plataforma de distribuci&oacute;n digital de videojuegos </span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Text"   datasizewidth="1.00px" datasizeheight="1.00px" dataX="38.50" dataY="375.09" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Steam"   datasizewidth="57.52px" datasizeheight="29.00px" dataX="42.00" dataY="178.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Steam</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="93.98px" datasizeheight="81.22px" dataX="211.00" dataY="178.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/5fbceacf-8929-4695-aabb-3e2eabf47c12.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Text button" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="A&ntilde;adir Plataforma"   datasizewidth="250.30px" datasizeheight="56.00px" dataX="54.69" dataY="390.19" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0"> &nbsp; &nbsp; &nbsp;A&ntilde;adir Plataforma</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_3" class="path firer click commentable non-processed" customid="Add icon"   datasizewidth="12.00px" datasizeheight="12.00px" dataX="82.27" dataY="411.19"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="11.999999999999773" height="12.0" viewBox="82.26930291047722 411.1906294617761 11.999999999999773 12.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-daec8" d="M94.269302910477 418.04777231891893 L89.12644576761996 418.04777231891893 L89.12644576761996 423.1906294617761 L87.41216005333428 423.1906294617761 L87.41216005333428 418.04777231891893 L82.26930291047722 418.04777231891893 L82.26930291047722 416.33348660463326 L87.41216005333428 416.33348660463326 L87.41216005333428 411.1906294617761 L89.12644576761996 411.1906294617761 L89.12644576761996 416.33348660463326 L94.269302910477 416.33348660463326 L94.269302910477 418.04777231891893 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-daec8" fill="#6750A4" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_37" class="group firer ie-background commentable hidden non-processed" customid="Basic dialog" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="315.00px" datasizeheight="208.00px" datasizewidthpx="315.0000000000002" datasizeheightpx="208.00000000000006" dataX="22.50" dataY="342.09" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_6_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_24" class="richtext manualfit firer ie-background commentable non-processed" customid="Headline"   datasizewidth="257.69px" datasizeheight="31.00px" dataX="41.50" dataY="366.36" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_24_0">Reclamar Descuento</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_25" class="richtext manualfit firer ie-background commentable non-processed" customid="Supporting text"   datasizewidth="281.34px" datasizeheight="62.40px" dataX="41.50" dataY="405.36" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_25_0">&iquest;Confirmar reclamo de c&oacute;digo de descuento del 5% en la proxima compra &nbsp; &nbsp; &nbsp;en Steam?</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_10" class="button multiline manualfit firer click commentable non-processed" customid="No"   datasizewidth="76.00px" datasizeheight="38.00px" dataX="236.50" dataY="494.62" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_10_0">No</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_11" class="button multiline manualfit firer click commentable non-processed" customid="S&iacute;"   datasizewidth="76.00px" datasizeheight="38.00px" dataX="141.50" dataY="494.62" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_11_0">S&iacute;</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_59" class="group firer ie-background commentable hidden non-processed" customid="Radio button list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_12" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="315.00px" datasizeheight="386.41px" datasizewidthpx="315.0" datasizeheightpx="386.4147628213851" dataX="21.50" dataY="297.18" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_12_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_18" class="button multiline manualfit firer click commentable non-processed" customid="Cancelar"   datasizewidth="76.00px" datasizeheight="39.79px" dataX="244.00" dataY="637.94" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_18_0">Cancelar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_19" class="button multiline manualfit firer click commentable non-processed" customid="Aceptar"   datasizewidth="76.00px" datasizeheight="39.79px" dataX="157.56" dataY="636.90" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_19_0">Aceptar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_103" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="314.83px" datasizeheight="2.00px" dataX="21.25" dataY="630.36"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="314.32922900617643" height="1.5" viewBox="21.249999999999773 630.3623753003847 314.32922900617643 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_103-daec8" d="M21.499999999999773 630.6123753003847 L335.3292290061762 630.6123753003847 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_103-daec8" fill="none" stroke-width="0.5" stroke="#1E192B" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_38" class="richtext manualfit firer ie-background commentable non-processed" customid="Nintendo"   datasizewidth="101.64px" datasizeheight="21.99px" dataX="134.28" dataY="366.72" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_38_0">Nintendo</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_39" class="richtext manualfit firer ie-background commentable non-processed" customid="Steam"   datasizewidth="96.91px" datasizeheight="21.99px" dataX="136.64" dataY="419.08" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_39_0">Steam</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_40" class="richtext manualfit firer ie-background commentable non-processed" customid="Epic Game"   datasizewidth="96.91px" datasizeheight="21.99px" dataX="136.64" dataY="471.96" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_40_0">Epic Game</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_102" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="314.83px" datasizeheight="2.00px" dataX="24.92" dataY="343.43"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="314.32922900617655" height="1.5" viewBox="24.920770993823908 343.4310880021198 314.32922900617655 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_102-daec8" d="M25.170770993823908 343.6810880021198 L339.00000000000045 343.6810880021198 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_102-daec8" fill="none" stroke-width="0.5" stroke="#1E192B" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_41" class="richtext manualfit firer ie-background commentable non-processed" customid="Headline"   datasizewidth="265.00px" datasizeheight="64.93px" dataX="55.00" dataY="284.19" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_41_0">Seleccionar Plataforma</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Radio buttons" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Input_7" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 2"  datasizewidth="20.00px" datasizeheight="23.27px" dataX="83.12" dataY="366.77"  name="s-Group_59"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Input_8" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 2"  datasizewidth="20.00px" datasizeheight="23.27px" dataX="83.12" dataY="419.13"  name="s-Group_59"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Input_9" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 2"  datasizewidth="20.00px" datasizeheight="23.27px" dataX="83.12" dataY="469.16"  name="s-Group_59"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Radio_2" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 2"  datasizewidth="20.00px" datasizeheight="23.27px" dataX="83.12" dataY="573.88"  name="s-Group_59"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Radio_1" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 2"  datasizewidth="20.00px" datasizeheight="23.27px" dataX="83.12" dataY="522.68"  name="s-Group_59"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Play Station"   datasizewidth="96.91px" datasizeheight="21.99px" dataX="136.64" dataY="523.92" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_3_0">Play Station</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_4" class="richtext manualfit firer ie-background commentable hidden non-processed" customid="Xbox"   datasizewidth="96.91px" datasizeheight="21.00px" dataX="136.54" dataY="574.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Xbox</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;