var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-80d0b2bc-1f32-4ebf-9e5a-a8107157e556" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Menu Principal - Juegos"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/80d0b2bc-1f32-4ebf-9e5a-a8107157e556/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/80d0b2bc-1f32-4ebf-9e5a-a8107157e556/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Path_2" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="29.78px" datasizeheight="22.75px" dataX="20.15" dataY="42.44"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.781021897810618" height="22.751039773296327" viewBox="20.145985401460415 42.44391404244118 29.781021897810618 22.751039773296327" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-80d0b" d="M49.92700729927103 52.397493943258326 L27.274817376241852 52.397493943258326 L37.67956218580339 44.448849205492095 L35.036496350365724 42.44391404244118 L20.145985401460415 53.81943392908934 L35.036496350365724 65.1949538157375 L37.66094884298222 63.190018483178136 L27.274817376241852 55.241373914920366 L49.92700729927103 55.241373914920366 L49.92700729927103 52.397493943258326 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-80d0b" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer ie-background commentable non-processed" customid="Line 3"   datasizewidth="362.00px" datasizeheight="3.00px" dataX="-0.50" dataY="79.86"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="360.999999999999" height="2.0" viewBox="-0.49999999999926104 79.86231366460125 360.999999999999 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-80d0b" d="M7.389644451905042E-13 80.36231366460125 L359.9999999999997 80.36231366460125 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-80d0b" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer click commentable non-processed" customid="Search"   datasizewidth="31.97px" datasizeheight="31.85px" dataX="308.76" dataY="37.55"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="31.970802919708547" height="31.8487154188659" viewBox="308.75912408759064 37.55254325107278 31.970802919708547 31.8487154188659" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-80d0b" d="M331.60846895472366 57.583182175551556 L330.1643903198974 57.583182175551556 L329.6525649926945 57.091521018777485 C331.44395339275763 55.01561873672591 332.522442749409 52.320586414759035 332.522442749409 49.38882988826478 C332.522442749409 42.851557452327356 327.2031155432631 37.55254325107278 320.64078341849984 37.55254325107278 C314.0784512937365 37.55254325107278 308.75912408759064 42.851557452327356 308.75912408759064 49.38882988826478 C308.75912408759064 55.92610232420221 314.0784512937365 61.225116525456784 320.64078341849984 61.225116525456784 C323.58377906353553 61.225116525456784 326.2891413127611 60.15074593999151 328.37300175640297 58.366197965267645 L328.8665476251448 58.87606877642515 L328.8665476251448 60.31463288371144 L338.00628557199803 69.40125866993867 L340.7299270072992 66.68801805031464 L331.60846895472366 57.583182175551556 Z M320.64078341849984 57.583182175551556 C316.0891943393509 57.583182175551556 312.4150192663319 53.92303773711049 312.4150192663319 49.38882988826478 C312.4150192663319 44.854622039419084 316.0891943393509 41.19447760097801 320.64078341849984 41.19447760097801 C325.1923724976487 41.19447760097801 328.8665475706677 44.854622039419084 328.8665475706677 49.38882988826478 C328.8665475706677 53.92303773711049 325.1923724976487 57.583182175551556 320.64078341849984 57.583182175551556 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-80d0b" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Primary tabs text" datasizewidth="360.00px" datasizeheight="52.00px" dataX="-0.00" dataY="728.00" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel"  datasizewidth="360.00px" datasizeheight="52.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.00px" datasizeheight="47.50px" datasizewidthpx="360.0" datasizeheightpx="47.5" dataX="0.00" dataY="2.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_5_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_6" class="rectangle manualfit firer click commentable non-processed" customid="Tab 3"   datasizewidth="120.00px" datasizeheight="39.00px" datasizewidthpx="120.00000000000023" datasizeheightpx="39.00000000000007" dataX="240.00" dataY="2.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_6_0">Juegos</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_7" class="rectangle manualfit firer click commentable non-processed" customid="Tab 2"   datasizewidth="120.00px" datasizeheight="40.00px" datasizewidthpx="119.99999999999977" datasizeheightpx="40.00000000000004" dataX="120.00" dataY="2.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_7_0">Trending</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_8" class="rectangle manualfit firer click ie-background commentable non-processed" customid="Tab 1"   datasizewidth="120.00px" datasizeheight="40.00px" datasizewidthpx="119.99999999999989" datasizeheightpx="40.0" dataX="0.43" dataY="2.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_8_0">Rese&ntilde;as</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_9" class="rectangle manualfit firer commentable non-processed" customid="Select tab"   datasizewidth="45.00px" datasizeheight="3.00px" datasizewidthpx="45.0" datasizeheightpx="3.0" dataX="278.93" dataY="47.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_9_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Card with image" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="387.00px" datasizewidthpx="314.0" datasizeheightpx="387.0" dataX="23.00" dataY="167.49" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Explora el Salvaje Oeste "   datasizewidth="283.00px" datasizeheight="72.00px" dataX="38.50" dataY="423.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">Explora el Salvaje Oeste con Arthur Morgan en esta &eacute;pica historia de honor, traici&oacute;n y supervivencia. Disfruta de un mundo abierto lleno de detalles y aventuras.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Acci&oacute;n, Aventura, Mundo A"   datasizewidth="283.00px" datasizeheight="21.00px" dataX="38.50" dataY="396.99" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Acci&oacute;n, Aventura, Mundo Abierto</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Red Dead Redemption 2"   datasizewidth="283.00px" datasizeheight="29.00px" dataX="38.50" dataY="363.99" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Red Dead Redemption 2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Image space"   datasizewidth="312.00px" datasizeheight="177.81px" datasizewidthpx="312.0" datasizeheightpx="177.81203007518792" dataX="24.00" dataY="168.49" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Card with image" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="137.00px" datasizewidthpx="314.0000000000002" datasizeheightpx="137.00000263082597" dataX="23.00" dataY="590.82" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Image space"   datasizewidth="312.00px" datasizeheight="124.14px" datasizewidthpx="311.9999999999999" datasizeheightpx="124.14065537387887" dataX="24.00" dataY="592.68" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image lockV firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="314.00px" datasizeheight="180.18px" dataX="23.00" dataY="167.49" aspectRatio="0.57382846"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/ecfe4b23-29eb-446b-b716-664777b694cb.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="4.8/5"   datasizewidth="35.59px" datasizeheight="18.00px" dataX="64.00" dataY="508.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">4.8/5</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_11" class="path firer commentable non-processed" customid="Star"   datasizewidth="20.00px" datasizeheight="19.00px" dataX="37.04" dataY="506.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="19.0" viewBox="37.03649635036609 506.0 20.0 19.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_11-80d0b" d="M47.03649635036609 521.2700004577637 L53.216496655541874 525.0 L51.57649666984699 517.9699997901917 L57.03649635036609 513.2399997711182 L49.846496293145634 512.629999756813 L47.03649635036609 506.0 L44.226495930749394 512.6300001144409 L37.03649635036609 513.2399997711182 L42.496496388513066 517.9699997901917 L40.85649652202747 525.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-80d0b" fill="#FFEB3B" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="314.00px" datasizeheight="129.59px" dataX="23.00" dataY="589.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/29f400d4-e5d2-4b44-ac5d-91114a656578.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="MATA-Critics"   datasizewidth="217.90px" datasizeheight="32.00px" dataX="71.05" dataY="37.48" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">MATA-Critics</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="180.00px" datasizeheight="70.44px" dataX="0.00" dataY="80.36" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Group"   datasizewidth="43.80px" datasizeheight="38.76px" dataX="68.10" dataY="96.20"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="43.795620437956075" height="38.76103072487501" viewBox="68.10218978102225 96.20103813188837 43.795620437956075 38.76103072487501" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-80d0b" d="M97.96284007962865 112.81290844254909 C101.26741864622733 112.81290844254909 103.91506305813576 109.1029239807547 103.91506305813576 104.50697328721873 C103.91506305813576 99.91102259368276 101.2674184089162 96.20103813188837 97.96284007962865 96.20103813188837 C94.65826151303 96.20103813188837 91.99071001990737 99.91102259368276 91.99071001990737 104.50697328721873 C91.99071001990737 109.1029239807547 94.65826151303 112.81290844254909 97.96284007962865 112.81290844254909 Z M82.0371599203719 112.81290844254909 C85.34173848697057 112.81290844254909 87.989382898879 109.1029239807547 87.989382898879 104.50697328721873 C87.989382898879 99.91102259368276 85.34173824965944 96.20103813188837 82.0371599203719 96.20103813188837 C78.73258159108437 96.20103813188837 76.06502986065063 99.91102292373097 76.06502986065063 104.50697328721873 C76.06502986065063 109.10292365070649 78.73258135377324 112.81290844254909 82.0371599203719 112.81290844254909 Z M82.0371599203719 118.35019854610266 C77.3988057258675 118.35019854610266 68.10218978102225 121.58951313786415 68.10218978102225 128.0404562273214 L68.10218978102225 134.96206885676338 L95.97213005972156 134.96206885676338 L95.97213005972156 128.0404562273214 C95.97213005972156 121.58951346791237 86.67551411487631 118.35019854610266 82.0371599203719 118.35019854610266 Z M97.96284007962865 118.35019854610266 C97.38553419046738 118.35019854610266 96.72859985779381 118.40557144590052 96.0318513033641 118.48863080075431 C98.34107486000921 120.8142925716362 99.95355009953576 123.94286163196614 99.95355009953576 128.0404563614035 L99.95355009953576 134.96206885676338 L111.89781021897832 134.96206885676338 L111.89781021897832 128.0404562273214 C111.89781021897832 121.58951346791237 102.60119427413306 118.35019854610266 97.96284007962865 118.35019854610266 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-80d0b" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="180.00px" datasizeheight="70.44px" dataX="180.00" dataY="80.36" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer click commentable non-processed" customid="Account_circle"   datasizewidth="46.42px" datasizeheight="44.66px" dataX="246.79" dataY="93.25"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="46.423357664232924" height="44.659448443877864" viewBox="246.78832116788422 93.25182927238694 46.423357664232924 44.659448443877864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-80d0b" d="M270.0000000000007 93.25182927238694 C257.18715332894516 93.25182927238694 246.78832116788422 103.25554576640616 246.78832116788422 115.58155349432587 C246.78832116788422 127.90756122224559 257.18715332894516 137.9112777162648 270.0000000000007 137.9112777162648 C282.8128466710562 137.9112777162648 293.2116788321172 127.90756122224559 293.2116788321172 115.58155349432587 C293.2116788321172 103.25554576640616 282.8128477778753 93.25182927238694 270.0000000000007 93.25182927238694 Z M270.0000000000007 99.95074653896862 C273.85313860865466 99.95074653896862 276.96350364963564 102.94292965924194 276.96350364963564 106.6496638055503 C276.96350364963564 110.35639795185867 273.85313860865466 113.34858107213198 270.0000000000007 113.34858107213198 C266.1468613913467 113.34858107213198 263.0364963503657 110.35639795185867 263.0364963503657 106.6496638055503 C263.0364963503657 102.94292965924194 266.1468613913467 99.95074653896862 270.0000000000007 99.95074653896862 Z M270.0000000000007 131.65895450821623 C264.1970802919716 131.65895450821623 259.0672991815283 128.80074987169388 256.0729927007308 124.46878324486603 C256.1426277356707 120.0251681034049 265.3576642335774 117.5912283548711 270.0000000000007 117.5912283548711 C274.61912410972826 117.5912283548711 283.8573717757738 120.02516836959595 283.92700729927054 124.46878324486603 C280.93270081847305 128.80074987169388 275.80291970802983 131.65895450821623 270.0000000000007 131.65895450821623 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-80d0b" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click ie-background commentable non-processed" customid="Button"   datasizewidth="297.96px" datasizeheight="378.00px" dataX="30.02" dataY="170.99" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Button</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;