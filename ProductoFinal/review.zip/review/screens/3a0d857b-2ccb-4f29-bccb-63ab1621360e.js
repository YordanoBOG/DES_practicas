var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-3a0d857b-2ccb-4f29-bccb-63ab1621360e" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Buscar amigos"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/3a0d857b-2ccb-4f29-bccb-63ab1621360e/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/3a0d857b-2ccb-4f29-bccb-63ab1621360e/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="28.42px" datasizeheight="23.43px" dataX="34.27" dataY="33.12"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="28.421526607441002" height="23.425839566700226" viewBox="34.27301737955902 33.120470984015355 28.421526607441002 23.425839566700226" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-3a0d8" d="M62.694543987000024 43.36927579444671 L41.076420175690814 43.36927579444671 L51.006191305214315 35.1848728724246 L48.48378068327952 33.120470984015355 L34.27301737955902 44.83339076736547 L48.48378068327952 56.54631055071558 L50.98842765626834 54.48190848777023 L41.076420175690814 46.29750574028424 L62.694543987000024 46.29750574028424 L62.694543987000024 43.36927579444671 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-3a0d8" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer ie-background commentable non-processed" customid="Line 3"   datasizewidth="359.86px" datasizeheight="3.00px" dataX="1.64" dataY="70.44"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="358.85559706512134" height="2.0" viewBox="1.6444029348786273 70.44322068490284 358.85559706512134 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-3a0d8" d="M2.1444029348786273 70.94322068490284 L359.99999999999994 70.94322068490284 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-3a0d8" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_9" class="path firer commentable non-processed" customid="Filter List"   datasizewidth="23.27px" datasizeheight="16.23px" dataX="325.36" dataY="38.38"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.270216588922835" height="16.23445275560033" viewBox="325.3648917055385 38.38292526214446 23.270216588922835 16.23445275560033" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_9-3a0d8" d="M334.4144203790085 54.61737801774479 L339.5855796209914 54.61737801774479 L339.5855796209914 51.9116358918114 L334.4144203790085 51.9116358918114 L334.4144203790085 54.61737801774479 Z M325.3648917055385 38.38292526214446 L325.3648917055385 41.08866738807785 L348.63510829446136 41.08866738807785 L348.63510829446136 38.38292526214446 L325.3648917055385 38.38292526214446 Z M329.2432611370257 47.853022702911325 L344.7567388629742 47.853022702911325 L344.7567388629742 45.147280576977934 L329.2432611370257 45.147280576977934 L329.2432611370257 47.853022702911325 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-3a0d8" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_6" class="richtext autofit firer ie-background commentable non-processed" customid="Buscar amigos"   datasizewidth="158.73px" datasizeheight="27.00px" dataX="103.10" dataY="33.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">Buscar amigos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="richtext autofit firer ie-background commentable non-processed" customid="Sugeridos"   datasizewidth="99.06px" datasizeheight="25.00px" dataX="130.47" dataY="84.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Sugeridos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="23.00" dataY="192.95" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_2" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="41.00" dataY="211.94" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_2)">\
                            <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                            <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_2" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_2_0">A</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="23.00" dataY="305.11" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="@knekro"   datasizewidth="51.34px" datasizeheight="16.00px" dataX="97.00" dataY="350.09" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_3_0">@knekro</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Sergio Garc&iacute;a"   datasizewidth="228.52px" datasizeheight="21.00px" dataX="97.00" dataY="326.09" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">Sergio Garc&iacute;a</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_4" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="41.00" dataY="324.09" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_4)">\
                              <ellipse id="s-Ellipse_4" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_4" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_4_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Text_9" class="richtext autofit firer ie-background commentable non-processed" customid="@illojuan"   datasizewidth="54.05px" datasizeheight="16.00px" dataX="95.96" dataY="238.11" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_9_0">@illojuan</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_10" class="richtext manualfit firer ie-background commentable non-processed" customid="Juan Alberto"   datasizewidth="196.52px" datasizeheight="21.00px" dataX="95.96" dataY="214.11" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_10_0">Juan Alberto</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_1" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="39.96" dataY="212.11" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_1)">\
                              <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_1" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_1_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="23.00" dataY="418.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_7_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="@ibai"   datasizewidth="32.72px" datasizeheight="16.00px" dataX="97.00" dataY="463.48" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_5_0">@ibai</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Ibai Llanos"   datasizewidth="229.52px" datasizeheight="21.00px" dataX="97.00" dataY="439.48" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_6_0">Ibai Llanos</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_6" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="41.00" dataY="437.48" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_6)">\
                              <ellipse id="s-Ellipse_6" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_6" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_6_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_12" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_10" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="23.00" dataY="533.20" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_10_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_11" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="@TheGrefg"   datasizewidth="68.04px" datasizeheight="16.00px" dataX="97.00" dataY="578.19" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_7_0">@TheGrefg</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_8" class="richtext manualfit firer ie-background commentable non-processed" customid="David C&aacute;novas"   datasizewidth="223.52px" datasizeheight="21.00px" dataX="97.00" dataY="554.19" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_8_0">David C&aacute;novas</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_8" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_8 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="41.00" dataY="552.19" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_8" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_8)">\
                              <ellipse id="s-Ellipse_8" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_8" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_8" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_8_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_15" class="group firer ie-background commentable non-processed" customid="Stacked card" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_13" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="83.00px" datasizewidthpx="314.0" datasizeheightpx="83.0" dataX="23.00" dataY="649.90" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_13_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_14" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Paragraph_9" class="richtext autofit firer ie-background commentable non-processed" customid="Ra&uacute;l &Aacute;lvarez"   datasizewidth="80.05px" datasizeheight="16.00px" dataX="97.00" dataY="694.89" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_9_0">Ra&uacute;l &Aacute;lvarez</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_10" class="richtext manualfit firer ie-background commentable non-processed" customid="AuronPlay"   datasizewidth="221.52px" datasizeheight="21.00px" dataX="97.00" dataY="670.89" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_10_0">AuronPlay</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_10" customid="Leading avatar" class="shapewrapper shapewrapper-s-Ellipse_10 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="41.00" dataY="668.89" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_10" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_10)">\
                              <ellipse id="s-Ellipse_10" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Leading avatar" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_10" class="clipPath">\
                              <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_10" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_10_0">A</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Text"   datasizewidth="1.00px" datasizeheight="1.00px" dataX="-212.00" dataY="88.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable hidden non-processed" customid="Filtrado por: Actividad R"   datasizewidth="305.70px" datasizeheight="25.00px" dataX="19.66" dataY="153.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Filtrado por: Actividad Reciente</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable hidden non-processed" customid="Filtrado por: Ubicaci&oacute;n"   datasizewidth="220.10px" datasizeheight="25.00px" dataX="19.66" dataY="153.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Filtrado por: Ubicaci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext autofit firer ie-background commentable hidden non-processed" customid="Filtrado por: Intereses c"   datasizewidth="309.36px" datasizeheight="25.00px" dataX="16.00" dataY="153.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Filtrado por: Intereses comunes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext autofit firer ie-background commentable hidden non-processed" customid="Filtrado por: Seguidores "   datasizewidth="337.52px" datasizeheight="25.00px" dataX="11.24" dataY="153.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">Filtrado por: Seguidores en com&uacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="180.00px" datasizeheight="70.44px" dataX="-0.00" dataY="70.94" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer click commentable non-processed" customid="Group"   datasizewidth="43.80px" datasizeheight="38.76px" dataX="68.10" dataY="86.78"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="43.795620437956075" height="38.76103072487501" viewBox="68.1021897810225 86.78194515219045 43.795620437956075 38.76103072487501" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-3a0d8" d="M97.9628400796289 103.39381546285117 C101.26741864622758 103.39381546285117 103.91506305813601 99.68383100105677 103.91506305813601 95.0878803075208 C103.91506305813601 90.49192961398484 101.26741840891646 86.78194515219045 97.9628400796289 86.78194515219045 C94.65826151303025 86.78194515219045 91.99071001990762 90.49192961398484 91.99071001990762 95.0878803075208 C91.99071001990762 99.68383100105677 94.65826151303025 103.39381546285117 97.9628400796289 103.39381546285117 Z M82.03715992037216 103.39381546285117 C85.34173848697083 103.39381546285117 87.98938289887926 99.68383100105677 87.98938289887926 95.0878803075208 C87.98938289887926 90.49192961398484 85.3417382496597 86.78194515219045 82.03715992037216 86.78194515219045 C78.73258159108462 86.78194515219045 76.06502986065088 90.49192994403305 76.06502986065088 95.0878803075208 C76.06502986065088 99.68383067100856 78.7325813537735 103.39381546285117 82.03715992037216 103.39381546285117 Z M82.03715992037216 108.93110556640474 C77.39880572586776 108.93110556640474 68.1021897810225 112.17042015816622 68.1021897810225 118.62136324762349 L68.1021897810225 125.54297587706546 L95.97213005972182 125.54297587706546 L95.97213005972182 118.62136324762349 C95.97213005972182 112.17042048821445 86.67551411487656 108.93110556640474 82.03715992037216 108.93110556640474 Z M97.9628400796289 108.93110556640474 C97.38553419046764 108.93110556640474 96.72859985779407 108.9864784662026 96.03185130336436 109.06953782105639 C98.34107486000947 111.39519959193828 99.95355009953602 114.52376865226822 99.95355009953602 118.62136338170558 L99.95355009953602 125.54297587706546 L111.89781021897858 125.54297587706546 L111.89781021897858 118.62136324762349 C111.89781021897858 112.17042048821445 102.60119427413332 108.93110556640474 97.9628400796289 108.93110556640474 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-3a0d8" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="180.00px" datasizeheight="70.44px" dataX="180.00" dataY="70.94" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer click commentable non-processed" customid="Account_circle"   datasizewidth="46.42px" datasizeheight="44.66px" dataX="246.79" dataY="83.83"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="46.423357664232924" height="44.659448443877864" viewBox="246.78832116788408 83.83273629268908 46.423357664232924 44.659448443877864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-3a0d8" d="M270.00000000000057 83.83273629268908 C257.18715332894504 83.83273629268908 246.78832116788408 93.83645278670829 246.78832116788408 106.16246051462801 C246.78832116788408 118.48846824254773 257.18715332894504 128.49218473656694 270.00000000000057 128.49218473656694 C282.81284667105604 128.49218473656694 293.211678832117 118.48846824254773 293.211678832117 106.16246051462801 C293.211678832117 93.83645278670829 282.81284777787516 83.83273629268908 270.00000000000057 83.83273629268908 Z M270.00000000000057 90.53165355927075 C273.85313860865455 90.53165355927075 276.96350364963547 93.52383667954408 276.96350364963547 97.23057082585244 C276.96350364963547 100.9373049721608 273.85313860865455 103.92948809243411 270.00000000000057 103.92948809243411 C266.14686139134653 103.92948809243411 263.0364963503656 100.9373049721608 263.0364963503656 97.23057082585244 C263.0364963503656 93.52383667954408 266.14686139134653 90.53165355927075 270.00000000000057 90.53165355927075 Z M270.00000000000057 122.23986152851836 C264.1970802919714 122.23986152851836 259.06729918152814 119.38165689199603 256.07299270073065 115.04969026516817 C256.14262773567054 110.60607512370703 265.3576642335772 108.17213537517324 270.00000000000057 108.17213537517324 C274.6191241097281 108.17213537517324 283.8573717757737 110.60607538989808 283.92700729927043 115.04969026516817 C280.93270081847294 119.38165689199603 275.80291970802966 122.23986152851836 270.00000000000057 122.23986152851836 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-3a0d8" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="40.00" dataY="211.76"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4ed65e10-a352-49d1-bcb0-dec1b109b502.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="290.36px" datasizeheight="80.00px" dataX="35.00" dataY="193.80"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="40.00" dataY="322.80"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/66f3d836-4fec-497e-884b-394002bb932d.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="40.00" dataY="437.30"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e50477f2-0ac7-4c92-bd0e-de12d257f56b.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Basic menu with icons" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Group_4" class="group firer ie-background commentable hidden non-processed" customid="Menu with icons" datasizewidth="112.00px" datasizeheight="158.00px" >\
          <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="251.50px" datasizeheight="315.36px" datasizewidthpx="251.49999999999943" datasizeheightpx="315.3581615755304" dataX="109.00" dataY="68.00" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_2_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Item 4" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_3" class="rectangle manualfit firer click commentable non-processed" customid="Item 4"   datasizewidth="251.50px" datasizeheight="77.35px" datasizewidthpx="251.49999999999943" datasizeheightpx="77.34604710356143" dataX="109.00" dataY="306.35" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_3_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_8" class="richtext manualfit firer click ie-background commentable non-processed" customid="Seguidores en Com&uacute;n"   datasizewidth="162.63px" datasizeheight="42.00px" dataX="153.43" dataY="324.50" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_8_0">Seguidores en Com&uacute;n</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Item 3" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_5" class="rectangle manualfit firer click commentable non-processed" customid="Item 3"   datasizewidth="251.50px" datasizeheight="75.67px" datasizewidthpx="251.49999999999943" datasizeheightpx="75.66755634634568" dataX="109.00" dataY="230.58" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_5_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_11" class="richtext manualfit firer click ie-background commentable non-processed" customid="Intereses Comunes"   datasizewidth="159.63px" datasizeheight="42.00px" dataX="154.93" dataY="252.61" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_11_0">Intereses Comunes</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_13" class="group firer ie-background commentable non-processed" customid="Item 2" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_6" class="rectangle manualfit firer click commentable non-processed" customid="Item 2"   datasizewidth="251.30px" datasizeheight="75.57px" datasizewidthpx="251.2999999999994" datasizeheightpx="75.56755634634558" dataX="109.00" dataY="156.40" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_6_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_12" class="richtext manualfit firer click ie-background commentable non-processed" customid="Ubicaci&oacute;n"   datasizewidth="159.63px" datasizeheight="33.15px" dataX="154.93" dataY="180.77" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_12_0">Ubicaci&oacute;n</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_16" class="group firer ie-background commentable non-processed" customid="Item 1" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_8" class="rectangle manualfit firer click commentable non-processed" customid="Item 1"   datasizewidth="251.50px" datasizeheight="75.77px" datasizewidthpx="251.49999999999943" datasizeheightpx="75.7675563463457" dataX="109.00" dataY="80.63" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_8_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_13" class="richtext manualfit firer click ie-background commentable non-processed" customid="Actividad Reciente"   datasizewidth="159.93px" datasizeheight="42.00px" dataX="154.79" dataY="98.95" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_13_0">Actividad Reciente</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_17" class="group firer ie-background commentable non-processed" customid="Item 1" datasizewidth="0.00px" datasizeheight="0.00px" >\
            <div id="s-Rectangle_9" class="rectangle manualfit firer click commentable non-processed" customid="Item 1"   datasizewidth="251.50px" datasizeheight="75.77px" datasizewidthpx="251.49999999999943" datasizeheightpx="75.7675563463457" dataX="109.00" dataY="383.97" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_9_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Text_14" class="richtext manualfit firer click ie-background commentable non-processed" customid="Sugeridos"   datasizewidth="159.93px" datasizeheight="42.00px" dataX="154.79" dataY="402.29" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Text_14_0">Sugeridos</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
        <div id="s-Hotspot_1" class="imagemap firer toggle ie-background commentable non-processed" customid="Hotspot"   datasizewidth="31.00px" datasizeheight="35.00px" dataX="329.50" dataY="27.00"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="40.00" dataY="552.01"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/85e1ccbc-8f5f-4dda-80a1-0bb0c66e6890.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="image firer ie-background commentable non-processed" customid="Image 5"   datasizewidth="45.00px" datasizeheight="45.00px" dataX="40.00" dataY="668.71"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d8e24203-defa-4e19-b3d8-b3fb888dc02b.png" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;