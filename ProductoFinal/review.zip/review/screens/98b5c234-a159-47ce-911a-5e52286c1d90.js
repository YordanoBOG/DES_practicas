var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738241432836.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-98b5c234-a159-47ce-911a-5e52286c1d90" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Juego"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/98b5c234-a159-47ce-911a-5e52286c1d90/style-1738241432836.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/98b5c234-a159-47ce-911a-5e52286c1d90/fonts-1738241432836.css" />\
      <div class="freeLayout">\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Card with image" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="314.00px" datasizeheight="646.72px" datasizewidthpx="314.0" datasizeheightpx="646.718333963428" dataX="23.00" dataY="106.77" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="Text"   datasizewidth="1.00px" datasizeheight="1.00px" dataX="-386.00" dataY="379.36" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_2" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="29.78px" datasizeheight="31.99px" dataX="20.15" dataY="44.85"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="29.781021897810547" height="31.98590116983023" viewBox="20.145985401460223 44.8485742949858 29.781021897810547 31.98590116983023" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_2-98b5c" d="M49.92700729927077 58.84240605678653 L27.274817376241643 58.84240605678653 L37.67956218580316 47.66733153053577 L35.036496350365496 44.8485742949858 L20.145985401460223 60.841524879900916 L35.036496350365496 76.83447546481602 L37.660948842981995 74.01571799095254 L27.274817376241643 62.84064370301531 L49.92700729927077 62.84064370301531 L49.92700729927077 58.84240605678653 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-98b5c" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="MATA-Critics"   datasizewidth="217.90px" datasizeheight="32.00px" dataX="71.05" dataY="34.24" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_5_0">MATA-Critics</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image lockV firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="314.00px" datasizeheight="180.18px" dataX="23.00" dataY="85.00" aspectRatio="0.57382846"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/ecfe4b23-29eb-446b-b716-664777b694cb.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Two lines item list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="306.00px" datasizeheight="54.00px" datasizewidthpx="306.0000000000002" datasizeheightpx="54.0" dataX="27.00" dataY="335.70" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Acci&oacute;n, Aventura, Mundo A"   datasizewidth="207.35px" datasizeheight="16.00px" dataX="36.96" dataY="363.38" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">Acci&oacute;n, Aventura, Mundo Abierto</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="G&eacute;nero:"   datasizewidth="282.18px" datasizeheight="21.00px" dataX="36.96" dataY="345.74" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">G&eacute;nero:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Two lines item list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="306.00px" datasizeheight="54.00px" datasizewidthpx="306.0000000000002" datasizeheightpx="54.0" dataX="27.00" dataY="389.70" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_6" class="richtext autofit firer ie-background commentable non-processed" customid="PS4, Xbox One, PC, Stadia"   datasizewidth="169.55px" datasizeheight="16.00px" dataX="36.96" dataY="417.38" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_6_0">PS4, Xbox One, PC, Stadia</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Plataformas:"   datasizewidth="282.18px" datasizeheight="21.00px" dataX="36.96" dataY="399.74" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_7_0">Plataformas:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Three lines item list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="306.00px" datasizeheight="98.00px" datasizewidthpx="306.0" datasizeheightpx="98.00000000000011" dataX="27.00" dataY="443.70" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Supporting text"   datasizewidth="292.40px" datasizeheight="60.31px" dataX="40.60" dataY="481.14" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Valoraci&oacute;n Promedio: &nbsp; &nbsp;4.8/5<br />N&uacute;mero de Rese&ntilde;as: 3,245<br />Likes Totales: 12,340 Likes</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Estad&iacute;sticas Generales:"   datasizewidth="165.14px" datasizeheight="19.00px" dataX="40.60" dataY="456.25" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Estad&iacute;sticas Generales:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Two lines item list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="306.00px" datasizeheight="70.00px" datasizewidthpx="306.0" datasizeheightpx="70.00000000000006" dataX="27.00" dataY="265.70" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_5_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Rockstar Games"   datasizewidth="106.20px" datasizeheight="16.00px" dataX="40.60" dataY="314.59" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">Rockstar Games</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Red Dead Redemption 2"   datasizewidth="283.18px" datasizeheight="32.22px" dataX="38.41" dataY="273.12" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">Red Dead Redemption 2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="26 de octubre de 2018"   datasizewidth="153.00px" datasizeheight="20.00px" dataX="180.00" dataY="312.59" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_1_0">26 de octubre de 2018</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Two lines item list" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="306.00px" datasizeheight="99.00px" datasizewidthpx="305.99999999999994" datasizeheightpx="99.0" dataX="27.00" dataY="541.70" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_6_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Red Dead Redemption 2 te "   datasizewidth="298.40px" datasizeheight="90.00px" dataX="30.80" dataY="543.64" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_7_0">Red Dead Redemption 2 te lleva al coraz&oacute;n del Salvaje Oeste con una historia &eacute;pica y un mundo abierto incre&iacute;blemente detallado. Juega como Arthur Morgan mientras lidias con lealtades rotas, forjas tu camino en la frontera y enfrentas el ocaso de la era de los forajidos.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Outlined button"   datasizewidth="108.00px" datasizeheight="40.00px" dataX="36.00" dataY="697.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Rese&ntilde;as</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_68" class="path firer commentable non-processed" customid="Favorite"   datasizewidth="35.00px" datasizeheight="35.00px" dataX="162.50" dataY="699.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="35.0" height="35.0" viewBox="162.49999999999957 699.4999999999998 35.0 35.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_68-98b5c" d="M179.99999999999957 734.4999999999998 L177.46249991655307 731.9822887806323 C168.45000016689258 723.0749307351813 162.49999999999957 717.2002716022818 162.49999999999957 709.9904629971772 C162.49999999999957 704.1158038642776 166.73500013351398 699.4999999999998 172.12499999999957 699.4999999999998 C175.17000001668887 699.4999999999998 178.09250015020328 701.0449591004952 179.99999999999957 703.4863757752174 C181.90750026702838 701.0449589868078 184.8300004005428 699.4999999999998 187.87499999999957 699.4999999999998 C193.26499986648517 699.4999999999998 197.49999999999957 704.1158038642776 197.49999999999957 709.9904629971772 C197.49999999999957 717.200272057031 191.54999983310657 723.07493164468 182.53749966621356 732.0013616494042 L179.99999999999957 734.4999999999998 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_68-98b5c" fill="#FF0000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="FAB" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_7" class="rectangle manualfit firer click commentable non-processed" customid="BG"   datasizewidth="56.00px" datasizeheight="56.00px" datasizewidthpx="56.0" datasizeheightpx="56.0" dataX="266.00" dataY="678.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_7_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer click commentable non-processed" customid="Edit icon"   datasizewidth="22.01px" datasizeheight="22.00px" dataX="283.00" dataY="695.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="22.009169787856763" height="22.0" viewBox="282.9954151060716 695.0 22.009169787856763 22.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-98b5c" d="M302.6297572559367 695.7151986375037 L304.2802161770864 697.3656572671721 C305.24604113287575 698.3192551590298 305.24604113287575 699.8719086450224 304.2802161770864 700.825507119843 L288.10572329692945 717.0 L282.9954151060716 717.0 L282.9954151060716 711.8896912261793 L295.71005755059474 699.1628228836504 L299.1699074032657 695.7151986375037 C300.12350646104926 694.7616004541645 301.67616053000467 694.7616004541645 302.6297572559367 695.7151986375037 Z M285.4405387427819 714.5548763632897 L287.1643507201145 714.6282294194725 L299.1699074032657 702.6104468383156 L297.4460954259331 700.8866354439459 L285.4405387427819 712.8921915441342 L285.4405387427819 714.5548763632897 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-98b5c" fill="#21005E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;