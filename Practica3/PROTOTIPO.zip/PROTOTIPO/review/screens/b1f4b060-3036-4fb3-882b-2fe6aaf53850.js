var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1736336928821.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-b1f4b060-3036-4fb3-882b-2fe6aaf53850" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Editar Perfil"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/b1f4b060-3036-4fb3-882b-2fe6aaf53850/style-1736336928821.css" />\
      <div class="freeLayout">\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="360.00px" datasizeheight="780.00px" dataX="0.00" dataY="0.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/1f705632-9313-442a-aded-c25b0b15ecc0.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="58.00px" datasizeheight="80.00px" dataX="0.00" dataY="22.05"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="309.00px" datasizeheight="80.00px" dataX="29.00" dataY="589.36"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="309.00px" datasizeheight="80.00px" dataX="25.50" dataY="686.00"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;