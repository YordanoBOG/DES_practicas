(function(window, undefined) {
  var dictionary = {
    "9b05cc5d-2842-44c7-bb4a-754cddb7e288": "Perfil amigo",
    "a392b054-2aed-45c1-82eb-c2f6a1abb043": "administrar_amigos",
    "b565dfad-06fb-4550-b589-4082519cd568": "Reseñas Rdr2",
    "60496877-adab-480b-940f-666c8d2e09ca": "Mis Plataformas",
    "9159379a-86b9-44d0-8b08-d632a02fd39e": "Juego Rdr2",
    "ecc2a641-2eed-4422-a55e-47c8f84826f1": "Perfil",
    "09b24a57-58a2-4570-9ce9-e52f2a4d92a3": "buscador",
    "b2024d71-1c73-4da3-ac7b-b0dea8d5e884": "TRENDING",
    "d7c6420b-e6db-4ae0-a716-1f6339f798a5": "pantallainicio",
    "ec2489c7-eff2-489b-988c-2f7e3db2103c": "grupo1",
    "fa436698-df5c-4a79-89b6-b1dae935e3f4": "lista_amigos",
    "a06a51fe-affc-48d6-a86d-ac698e3b577c": "Confirmar Descuento",
    "8aaa1584-ee9b-433f-8a76-061086333c33": "JUEGOS",
    "b1f4b060-3036-4fb3-882b-2fe6aaf53850": "Editar Perfil",
    "11f50284-7e1e-42e1-9487-4f2c9ab49a82": "crear_grupo",
    "e773f95c-a9f8-4485-852d-5429f8ce4853": "BUSCAR_AMIGOS",
    "fb8fc1d9-921c-4812-9790-1baa4a3051b6": "Reseña rdr2",
    "6cb27b01-f7dc-4974-82d7-e0987e3a83b1": "grupos",
    "0786e6ab-51a9-49ef-acd8-8ac66a247784": "Publicar Reseña",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Screen 1",
    "160a4686-3b40-4acf-909d-eb57a3ad3f47": "registro",
    "5d5d643f-1823-4661-b7c7-2721869deb05": "compartir_reseña",
    "201729ec-b3c9-40bc-babd-94206c8934f1": "iniciar_sesion",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "Board 1"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);