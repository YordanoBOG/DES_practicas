(function(window, undefined) {

  var jimLinks = {
    "9b05cc5d-2842-44c7-bb4a-754cddb7e288" : {
      "Hotspot_1" : [
        "e773f95c-a9f8-4485-852d-5429f8ce4853"
      ],
      "Hotspot_2" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ],
      "Hotspot_3" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ]
    },
    "a392b054-2aed-45c1-82eb-c2f6a1abb043" : {
      "Button_1" : [
        "fa436698-df5c-4a79-89b6-b1dae935e3f4"
      ],
      "Button_2" : [
        "6cb27b01-f7dc-4974-82d7-e0987e3a83b1"
      ],
      "Hotspot_1" : [
        "b1f4b060-3036-4fb3-882b-2fe6aaf53850"
      ]
    },
    "b565dfad-06fb-4550-b589-4082519cd568" : {
      "Hotspot_1" : [
        "fb8fc1d9-921c-4812-9790-1baa4a3051b6"
      ],
      "Hotspot_2" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ],
      "Hotspot_3" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ],
      "Hotspot_4" : [
        "d7c6420b-e6db-4ae0-a716-1f6339f798a5"
      ]
    },
    "60496877-adab-480b-940f-666c8d2e09ca" : {
      "Hotspot_1" : [
        "a06a51fe-affc-48d6-a86d-ac698e3b577c"
      ],
      "Hotspot_2" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ]
    },
    "9159379a-86b9-44d0-8b08-d632a02fd39e" : {
      "Hotspot_1" : [
        "8aaa1584-ee9b-433f-8a76-061086333c33"
      ],
      "Hotspot_2" : [
        "b565dfad-06fb-4550-b589-4082519cd568"
      ],
      "Hotspot_3" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ],
      "Hotspot_4" : [
        "0786e6ab-51a9-49ef-acd8-8ac66a247784"
      ],
      "Hotspot_5" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ]
    },
    "ecc2a641-2eed-4422-a55e-47c8f84826f1" : {
      "Hotspot_1" : [
        "b1f4b060-3036-4fb3-882b-2fe6aaf53850"
      ],
      "Hotspot_2" : [
        "d7c6420b-e6db-4ae0-a716-1f6339f798a5"
      ]
    },
    "09b24a57-58a2-4570-9ce9-e52f2a4d92a3" : {
      "Hotspot_1" : [
        "e773f95c-a9f8-4485-852d-5429f8ce4853"
      ],
      "Hotspot_2" : [
        "d7c6420b-e6db-4ae0-a716-1f6339f798a5"
      ]
    },
    "b2024d71-1c73-4da3-ac7b-b0dea8d5e884" : {
      "Button_1" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ],
      "Button_2" : [
        "d7c6420b-e6db-4ae0-a716-1f6339f798a5"
      ],
      "Button_3" : [
        "b2024d71-1c73-4da3-ac7b-b0dea8d5e884"
      ],
      "Button_4" : [
        "8aaa1584-ee9b-433f-8a76-061086333c33"
      ],
      "Button_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_1" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ],
      "Hotspot_2" : [
        "9159379a-86b9-44d0-8b08-d632a02fd39e"
      ],
      "Hotspot_3" : [
        "0786e6ab-51a9-49ef-acd8-8ac66a247784"
      ],
      "Hotspot_4" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ]
    },
    "d7c6420b-e6db-4ae0-a716-1f6339f798a5" : {
      "Button_1" : [
        "d7c6420b-e6db-4ae0-a716-1f6339f798a5"
      ],
      "Button_2" : [
        "b2024d71-1c73-4da3-ac7b-b0dea8d5e884"
      ],
      "Button_3" : [
        "8aaa1584-ee9b-433f-8a76-061086333c33"
      ],
      "Button_4" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ],
      "Button_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_1" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ],
      "Hotspot_2" : [
        "b565dfad-06fb-4550-b589-4082519cd568"
      ]
    },
    "ec2489c7-eff2-489b-988c-2f7e3db2103c" : {
      "Button_4" : [
        "6cb27b01-f7dc-4974-82d7-e0987e3a83b1"
      ]
    },
    "fa436698-df5c-4a79-89b6-b1dae935e3f4" : {
      "Button_1" : [
        "a392b054-2aed-45c1-82eb-c2f6a1abb043"
      ],
      "Hotspot_1" : [
        "a392b054-2aed-45c1-82eb-c2f6a1abb043"
      ]
    },
    "a06a51fe-affc-48d6-a86d-ac698e3b577c" : {
      "Hotspot_1" : [
        "60496877-adab-480b-940f-666c8d2e09ca"
      ],
      "Hotspot_2" : [
        "60496877-adab-480b-940f-666c8d2e09ca"
      ],
      "Hotspot_3" : [
        "60496877-adab-480b-940f-666c8d2e09ca"
      ]
    },
    "8aaa1584-ee9b-433f-8a76-061086333c33" : {
      "Button_1" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ],
      "Button_2" : [
        "d7c6420b-e6db-4ae0-a716-1f6339f798a5"
      ],
      "Button_3" : [
        "b2024d71-1c73-4da3-ac7b-b0dea8d5e884"
      ],
      "Button_4" : [
        "8aaa1584-ee9b-433f-8a76-061086333c33"
      ],
      "Button_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_1" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ],
      "Hotspot_2" : [
        "9159379a-86b9-44d0-8b08-d632a02fd39e"
      ],
      "Hotspot_4" : [
        "0786e6ab-51a9-49ef-acd8-8ac66a247784"
      ]
    },
    "b1f4b060-3036-4fb3-882b-2fe6aaf53850" : {
      "Hotspot_1" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ],
      "Hotspot_2" : [
        "60496877-adab-480b-940f-666c8d2e09ca"
      ],
      "Hotspot_3" : [
        "a392b054-2aed-45c1-82eb-c2f6a1abb043"
      ]
    },
    "11f50284-7e1e-42e1-9487-4f2c9ab49a82" : {
      "Button_1" : [
        "6cb27b01-f7dc-4974-82d7-e0987e3a83b1"
      ],
      "Button_2" : [
        "6cb27b01-f7dc-4974-82d7-e0987e3a83b1"
      ]
    },
    "e773f95c-a9f8-4485-852d-5429f8ce4853" : {
      "Button_1" : [
        "d7c6420b-e6db-4ae0-a716-1f6339f798a5"
      ],
      "Hotspot_1" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ],
      "Hotspot_3" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ],
      "Hotspot_2" : [
        "9b05cc5d-2842-44c7-bb4a-754cddb7e288"
      ],
      "Hotspot_4" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ]
    },
    "fb8fc1d9-921c-4812-9790-1baa4a3051b6" : {
      "Hotspot_1" : [
        "09b24a57-58a2-4570-9ce9-e52f2a4d92a3"
      ],
      "Hotspot_2" : [
        "ecc2a641-2eed-4422-a55e-47c8f84826f1"
      ],
      "Hotspot_3" : [
        "b565dfad-06fb-4550-b589-4082519cd568"
      ],
      "Hotspot_4" : [
        "5d5d643f-1823-4661-b7c7-2721869deb05"
      ]
    },
    "6cb27b01-f7dc-4974-82d7-e0987e3a83b1" : {
      "Radio_1" : [
        "11f50284-7e1e-42e1-9487-4f2c9ab49a82"
      ],
      "Button_1" : [
        "ec2489c7-eff2-489b-988c-2f7e3db2103c"
      ],
      "Button_2" : [
        "a392b054-2aed-45c1-82eb-c2f6a1abb043"
      ]
    },
    "0786e6ab-51a9-49ef-acd8-8ac66a247784" : {
      "Hotspot_1" : [
        "9159379a-86b9-44d0-8b08-d632a02fd39e"
      ],
      "Hotspot_2" : [
        "9159379a-86b9-44d0-8b08-d632a02fd39e"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "201729ec-b3c9-40bc-babd-94206c8934f1"
      ],
      "Button_2" : [
        "160a4686-3b40-4acf-909d-eb57a3ad3f47"
      ]
    },
    "160a4686-3b40-4acf-909d-eb57a3ad3f47" : {
      "Button_1" : [
        "d7c6420b-e6db-4ae0-a716-1f6339f798a5"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "5d5d643f-1823-4661-b7c7-2721869deb05" : {
      "Hotspot_1" : [
        "fb8fc1d9-921c-4812-9790-1baa4a3051b6"
      ]
    },
    "201729ec-b3c9-40bc-babd-94206c8934f1" : {
      "Button_1" : [
        "d7c6420b-e6db-4ae0-a716-1f6339f798a5"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);